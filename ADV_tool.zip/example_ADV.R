rm(list=ls())
gc()


require(readr)
require(dplyr)
require(lubridate)


path <- "../WGBIOPTIM"


HL_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Station_number","Species",     
"Catch_category","Landing_category","Comm_size_cat_scale","Comm_size_cat","Subsampling_category","Sex","Individual_sex","Length_class",
"Number_at_length");

HH_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Station_number",
"Fishing_validity","Aggregation_level","Catch_registration","Species_registration","Date","Time","Fishing_duration",
"Pos_Start_Lat_dec","Pos_Start_Lon_dec","Pos_Stop_Lat_dec","Pos_Stop_Lon_dec","Area","Statistical_rectangle","Sub_polygon",
"Main_fishing_depth","Main_water_depth","FAC_National","FAC_EC_lvl5","FAC_EC_lvl6","Gear_type","Mesh_size","Selection_device",
"Mesh_size_selection_device")

SL_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Station_number","Species",
"Catch_category","Landing_category","Comm_size_cat_scale","Comm_size_cat","Subsampling_category","Sex","Weight","Subsample_weight","Length_code")

CA_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Station_number",
"Quarter","Month","Species", "Sex","Catch_category","Landing_category","Comm_size_cat_scale","Comm_size_cat","Stock","Area","Statistical_rectangle",
"Sub_polygon","Length_class","Age","Single_fish_number","Length_code","Aging_method","Age_plus_group","Otolith_weight","Otolith_side","Weight",
"Maturity_staging_method","Maturity_scale","Maturity_stage")

# RDBES functions
lapply(list.files(path = paste0(path,"/RDBESfunctions"), full.names = TRUE), source)




########## Functions ###########

source(paste0(path, "../01_dataRDBEStoRDB.R"))
source(paste0(path, "../02_setdata.R"))
source(paste0(path, ../03_find_modes_antimodes.R"))
source(paste0(path, ../04_minimal_reference_subsample_construction.R"))
source(paste0(path, ../05_visualization.R"))
source(paste0(path, "/Presentation_2024/ADV_scripts_v2../06_compute_distance.R"))



file.names <- as.character(unzip("../data_example.zip", list = TRUE)$Name)

read.zip <- function(x) 
{
read.csv(unz("../data_example.zip", x), header = TRUE, sep=",")
}

list.rdbes <- lapply(file.names, read.zip)
names(list.rdbes) <- sub("\\.csv", "", basename(file.names))



####### Input data in RDB format - has to be changed

input.data <- dataRDBEStoRDB(list.rdbes, 1)

#
filtered.sample <- setData(input.data, selected.species="REG", selected.quarter=2, selected.area=c("27.14.b","27.14"), delta=5)

find_modes_antimodes(filtered.sample, smoothed=TRUE, delta=5)
#

reference.subsample <- subsampling(filtered.sample, delta=5) #### Number 1: original filtered sample: gamma/theta/epsilon keep the subsample identical to the original filtered sample

reference.subsample <- subsampling(filtered.sample, gamma=2) #### Number 2 

reference.subsample <- subsampling(filtered.sample, gamma=2, theta=0.9) #### Number 3

reference.subsample <- subsampling(filtered.sample, gamma=2, theta=0.8) #### Number 4
reference.subsample <- subsampling(filtered.sample, gamma=5, theta=0.8) #### Number 5


reference.subsample <- subsampling(filtered.sample, gamma=1, theta=0.5, delta=5) #### Number 6

cdf_adv(filtered.sample, reference.subsample) ### original vs Number 6
### ADV = 2.688


### Let's check, if exclusion from sampling several rectangles will lead to LFD change
my_real_subsample <- subset(filtered.sample, !(Statistical_rectangle %in% c("59B8","59B9","60B8","60B9")))

compare_distribution(filtered.sample, my_real_subsample, reference=FALSE, delta=5)

## Compute distance and compare it to ADV, which a baseline
cdf_adv(filtered.sample, my_real_subsample, reference=FALSE)
### Distance = 1.7218, less than ADV - so, if we exclude from sampling rectangles "59B8","59B9","60B8","60B9", the LFD remains similar





