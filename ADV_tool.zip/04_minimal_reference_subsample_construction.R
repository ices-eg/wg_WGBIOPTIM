#### This script describes iterative subsampling procedure for reference subsample ("worst case") construction
#### Inputs and parameters: data - input data set; delta - parameter defining smoothing level; theta - parameter defining amplitude ratio; epsion - parameter defining tolerated critical poits shift;
#### gamma - parameter defining minimally permitted number per length class; important - defined important length classes
#### Ouputs: data set representing reference subsample + 2 histogram plots comparing original data set and reference subsample (with bin width = 1 cm and bin width = delta > 1 cm)

subsampling <- function(data, delta=1, theta=1, epsilon = 0, gamma, important)
{


if (missing(important)) 
{
M <- max(data$LengthClass_cm);
cl <- seq(0, M, by=1);
important <- c(0:M);
}


if (missing(gamma)) ### not sure about this!!!
{
U <- data.frame(table(factor(data$LengthClass_cm, levels=seq(0, M, by=1))));
names(U) <- c("LengthClass_cm", "freq");
gamma <- max(U$freq)

min_per_length_class <- c();

for (j in cl)
{
if(!(j %in% important)) n.cl <- n_in_j else n.cl <- gamma;
min_per_length_class <- c(min_per_length_class, round(n.cl));
}

U <- data.frame(table(factor(data$LengthClass_cm, levels=seq(0, M, by=1))));
U <- cbind(U, min_per_length_class);

names(U) <- c("LengthClass_cm", "freq", "min_num_lc");

U$min_num_lc <- ifelse(U$min_num_lc>U$freq, U$freq, U$min_num_lc)

U$LengthClass_cm <- as.numeric(as.character(U$LengthClass_cm));
U$freq <- as.numeric(as.character(U$freq));
U$min_num_lc <- as.numeric(as.character(U$min_num_lc));
} else

{
if (gamma < 1)
{
min_per_length_class <- c();

for (j in cl)
{
n_in_j <- nrow(subset(data, LengthClass_cm==j));
if(!(j %in% important)) n.cl <- n_in_j else n.cl <- ifelse(n_in_j>=5, gamma*n_in_j, n_in_j);
min_per_length_class <- c(min_per_length_class, round(n.cl));
}

U <- data.frame(table(factor(data$LengthClass_cm, levels=seq(0, M, by=1))));
U <- cbind(U, min_per_length_class);

names(U) <- c("LengthClass_cm", "freq", "min_num_lc");

U$LengthClass_cm <- as.numeric(as.character(U$LengthClass_cm));
U$freq <- as.numeric(as.character(U$freq));
U$min_num_lc <- as.numeric(as.character(U$min_num_lc));

} else

{
min_per_length_class <- c();

for (j in cl)
{
if(!(j %in% important)) n.cl <- n_in_j else n.cl <- gamma;
min_per_length_class <- c(min_per_length_class, round(n.cl));
}

U <- data.frame(table(factor(data$LengthClass_cm, levels=seq(0, M, by=1))));
U <- cbind(U, min_per_length_class);

names(U) <- c("LengthClass_cm", "freq", "min_num_lc");

U$min_num_lc <- ifelse(U$min_num_lc>U$freq, U$freq, U$min_num_lc)

U$LengthClass_cm <- as.numeric(as.character(U$LengthClass_cm));
U$freq <- as.numeric(as.character(U$freq));
U$min_num_lc <- as.numeric(as.character(U$min_num_lc));
}

}

########################

data_important <- subset(data, LengthClass_cm %in% important);

data_not_important <- subset(data, !(LengthClass_cm %in% important));

data <- data_important;


if (delta>1)
{
u <- find_modes_antimodes(data, smoothed=TRUE, delta=delta, important = important)$modes_robust;
v <- find_modes_antimodes(data, smoothed=TRUE, delta=delta, important = important)$antimodes_robust;
} else
{
u <- find_modes_antimodes(data, smoothed=FALSE, delta=delta, important = important)$modes_robust;
v <- find_modes_antimodes(data, smoothed=FALSE, delta=delta, important = important)$antimodes_robust;
}

critical_points_robust <- sort(c(u,v))

#cat("Modes original: ", u, fill=TRUE)
#cat("Antimodes original: ", v, fill=TRUE)

if (delta>1)
y.diff <- find_modes_antimodes(data, smoothed=TRUE, delta=delta, important = important)$amplitudes_robust else 
y.diff <- find_modes_antimodes(data, smoothed=FALSE, delta=delta, important = important)$amplitudes_robust;


subsample <- data;
subsample_previous <- subsample;
U_sub <- U;

critical_points_robust_sub <- critical_points_robust;

#y.diff <- y.diff[y.diff>0]

y.diff_sub <- y.diff;


#cat("Ratio original: ", y.diff_sub/y.diff, fill=TRUE)

contrsubsample <- c();
contrsubsample_previous <- contrsubsample;

t <- 1;

#cat("**********",fill=TRUE);


min_number_LC <- U_sub$min_num_lc;


repeat 
{

if(length(critical_points_robust) == length(critical_points_robust_sub))
{

if(all(abs(critical_points_robust - critical_points_robust_sub)<=epsilon)  & all(y.diff_sub/y.diff >=theta) & any(U_sub$freq > min_number_LC))

{

#cat("t=",t,fill=TRUE)
subsample_previous <- subsample;
contrsubsample_previous <- contrsubsample;
U_sub_previous <- U_sub;

n <- which(U_sub$freq > min_number_LC & U_sub$freq > 0 & U_sub$LengthClass_cm %in% important);

s <- U_sub[n,]$LengthClass_cm;

fun_sub <- function(u) { nn <- which(subsample$LengthClass_cm == u); if(length(nn) > 1) rows <- sample(nn, 1, replace=FALSE) else { if (length(nn)==1)  rows <- nn } ;  return(rows)};


z <- unlist(lapply(s, fun_sub));

#print(length(z))

to_csub <- subsample[z,];
contrsubsample <- data.frame(rbind(contrsubsample, to_csub));

subsample <- subsample[-z,];


J <- data.frame(table(factor(subsample$LengthClass_cm, levels=seq(0, M, by=1))));

U_sub <- J

names(U_sub) <- c("LengthClass_cm", "freq");

U_sub$LengthClass_cm <- as.numeric(as.character(U_sub$LengthClass_cm));
U_sub$freq <- as.numeric(as.character(U_sub$freq));

if (delta>1)
{
u_sub <- find_modes_antimodes(subsample, smoothed=TRUE, delta=delta, important = important)$modes_robust;
v_sub <- find_modes_antimodes(subsample, smoothed=TRUE, delta=delta, important = important)$antimodes_robust;
} else
{
u_sub <- find_modes_antimodes(subsample, smoothed=FALSE, delta=delta, important = important)$modes_robust;
v_sub <- find_modes_antimodes(subsample, smoothed=FALSE, delta=delta, important = important)$antimodes_robust;
}

critical_points_robust_sub <- sort(c(u_sub, v_sub));

#cat("modes iterative: ", u_sub, fill=TRUE)
#cat("antimodes iterative: ", v_sub, fill=TRUE)

if (delta>1)
y.diff_sub <- find_modes_antimodes(subsample, smoothed=TRUE, delta=delta, important = important)$amplitudes_robust else 
y.diff_sub <- find_modes_antimodes(subsample, smoothed=FALSE, delta=delta, important = important)$amplitudes_robust;


y.diff_sub <- y.diff_sub[y.diff_sub>0]

if (length(critical_points_robust) == length(critical_points_robust_sub))
#cat("Ratio iterative: ", y.diff_sub/y.diff, fill=TRUE);


if (delta>1)
{
u_sub_previous <- find_modes_antimodes(subsample_previous, smoothed=TRUE, delta=delta, important = important)$modes_robust;
v_sub_previous <- find_modes_antimodes(subsample_previous, smoothed=TRUE, delta=delta, important = important)$antimodes_robust;
} else
{
u_sub_previous <- find_modes_antimodes(subsample_previous, smoothed=FALSE, delta=delta)$modes_robust;
v_sub_previous <- find_modes_antimodes(subsample_previous, smoothed=FALSE, delta=delta)$antimodes_robust;
}


critical_points_robust_sub_previous <- sort(c(u_sub_previous, v_sub_previous));


if (delta>1)
y.diff_sub_previous <- find_modes_antimodes(subsample_previous, smoothed=TRUE, delta=delta, important = important)$amplitudes_robust else 
y.diff_sub_previous <- find_modes_antimodes(subsample_previous, smoothed=FALSE, delta=delta, important = important)$amplitudes_robust;

#cat("**********",fill=TRUE);

t <- t + 1;

#print(dim(contrsubsample))

} else 

{
#cat("########################################", fill=TRUE);
#cat("########## STOPPING RULE: ##############", fill=TRUE);
#cat("########################################", fill=TRUE);
#cat("",fill=TRUE);

### 1
#if (any(abs(critical_points_robust - critical_points_robust_sub)>epsilon)) 
#{
#cat("########################################", fill=TRUE);
#cat("CP: ", critical_points_robust_sub,fill=TRUE);
#cat("CP difference > epsilon: ", abs(critical_points_robust - critical_points_robust_sub),fill=TRUE);
#}

### 2
#if (all(U_sub$freq <= min_number_LC)) 
#{
#cat("########################################", fill=TRUE);
#cat("LC number < gamma = ", gamma, fill=TRUE);
#print(U_sub[which(U_sub$freq <= min_number_LC),])
#cat("########################################", fill=TRUE);
#}

### 3

#if (any(y.diff_sub/y.diff<theta))
#{
#cat("########################################", fill=TRUE);
#cat("Amplitudes ratio < theta: ", y.diff_sub/y.diff, fill=TRUE);
#cat("########################################", fill=TRUE);
#}


break; 
} 

} else 

{

## 4
#cat("########################################", fill=TRUE);
#cat("########## STOPPING RULE: ##############", fill=TRUE);
#cat("########################################", fill=TRUE);
#cat("",fill=TRUE);
#cat("########################################", fill=TRUE);
#cat("Number critical points changed!", fill=TRUE); 
#cat("CP: ", critical_points_robust_sub,fill=TRUE);
#cat("Number of CP: ", length(critical_points_robust_sub),fill=TRUE);
#cat("########################################", fill=TRUE);

break; 

}


}

final_subsample_unsuitable <- subsample;
subsample <- subsample_previous;
contrsubsample <- contrsubsample_previous;



subsample_full <- rbind(data_not_important, subsample);

if (!is.null(contrsubsample_previous)) contrsubsample <- subset(contrsubsample, !(rownames(contrsubsample) %in% rownames(to_csub)));

compare_distribution(data, subsample_full, delta=delta, important=important)


return(subsample_full);


}