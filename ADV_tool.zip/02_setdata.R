#### The script defines original data set.
#### Inputs: HL, HH and SL tables, as well as selected species, country, metier, year, quarter etc., and also desired (if any) bin width = delta
#### Outputs: desired data set + 2 histogram plots (with bin width = 1 cm and bin width = delta > 1 cm)
#### Remarks: input data could be in DATRAS format as well, as alternative format - expand to surveys?




setData <- function(x, selected.species, selected.country, selected.year, 
selected.quarter, selected.area, selected.metier, selected.sampType, delta=1, verbose=FALSE)

{

require(ggplot2)
require(lattice)
require(latticeExtra)
require(gridExtra)
require(grid)
require(plyr)
require(FSA)
require(splitstackshape)
require(mondate)
require(devtools)
#install_github("ices-tools-prod/icesVocab")
require(icesVocab)
	
FAO <- getCodeList("SpecASFIS")[,c("Key","Description")]
names(FAO) <- c("FAO","latin_name")
WORMS <- getCodeList("SpecWoRMS")[,c("Key","Description")]


### Extract tables

HL <- x$HL
SL <- x$SL
HH <- x$HH

HL <- merge(HL, WORMS, by.x="Species", by.y="Key", all.x=TRUE)
HL <- merge(HL, FAO, by.x="Description", by.y="latin_name", all.x=TRUE)

HH$Month <- as.numeric(substr(HH$Date, 6, 7)) 
HH$Quarter <- ifelse(HH$Month %in% 1:3, 1, ifelse(HH$Month %in% 4:6, 2, ifelse(HH$Month %in% 7:9, 3, 4)))

################ Final data set species consists of combination of HL, SL and HH, might be extended for CA #####

HLSL <- merge(HL[names(HL)!="Record_type"], SL[names(SL)!="Record_type"], by=c("Year","Landing_country", 
"Trip_number","Station_number","Species", "Catch_category",
"Landing_category", "Comm_size_cat_scale", "Comm_size_cat", "Subsampling_category", "Sex"), all.x=TRUE)

HLSLHH <- merge(HLSL, HH[names(HH)!="Record_type"], by=c("Year","Trip_number","Station_number","Project","Vessel_flag_country",
"Landing_country","Sampling_type"), all.x=TRUE)


##### Choice of country, if any ############

if (!(missing(selected.country))) HLSLHH <- subset(HLSLHH, Vessel_flag_country %in% selected.country)

##### Choice of year, if any ############

if (!(missing(selected.year))) HLSLHH <- subset(HLSLHH, Year %in% selected.year) else selected.year <- sort(unique(HLSLHH$Year))

##### Choice of quarter, if any ############

if (!(missing(selected.quarter))) HLSLHH <- subset(HLSLHH, Quarter %in% selected.quarter) else selected.quarter <- sort(unique(HLSLHH$Quarter))

##### Choice of sampling type, if any ############

if (!(missing(selected.sampType))) HLSLHH <- subset(HLSLHH, Sampling_type %in% selected.sampType)

##### Choice of metier, if any ############

if (!(missing(selected.metier))) HLSLHH <- subset(HLSLHH, FAC_EC_lvl6 %in% selected.metier)

##### Choice of area, if any ############

if (!(missing(selected.area))) HLSLHH <- subset(HLSLHH, Area %in% selected.area)

##### Choice of species #################

HLSLHH <- subset(HLSLHH, FAO %in% selected.species);

###### Data cleaning ##################################

HLSLHH$LengthClass_cm <- floor(as.numeric(HLSLHH$Length_class)/10);


#########################################################################################################################################################################
######## Raising at haul level ########################################################################################################################
#########################################################################################################################################################################

HLSLHH$Subsample_weight <- ifelse(HLSLHH$Subsample_weight==0 & HLSLHH$Number_at_length>0, HLSLHH$Weight, HLSLHH$Subsample_weight);

HLSLHH$NoAtLength_Raised_to_Haul <- floor(as.numeric(HLSLHH$Number_at_length)*as.numeric(HLSLHH$Weight)/as.numeric(HLSLHH$Subsample_weight))


################ Extracting data: one row = one fish  ################################

final.data <- expandRows(HLSLHH, "NoAtLength_Raised_to_Haul")

final.data$n <- 1;



##### Binwidth ############

if (missing(delta)) delta <- 1;


################ Plot ###################

M <- max(as.numeric(final.data$LengthClass_cm));

U <- c();

for (k in 1:length(selected.year))
{
U1 <- data.frame(selected.year[k], table(factor(subset(final.data, Year==selected.year[k])$LengthClass_cm, levels=seq(0, M, by=1))));
names(U1) <- c("year","LengthClass_cm", "freq");
U <- rbind(U,U1)
}

r <- max(U$freq)


dev.new();

p <- ggplot(final.data, aes(x=LengthClass_cm)) + 
facet_wrap(~Year) +
geom_histogram(data = final.data, aes(x = LengthClass_cm), binwidth = 1, boundary=0, closed="left",  colour="black",fill="turquoise") + 
xlim(0,M)+
ylim(0,r)+
labs(title="LFD", x="LENGTH", y = "COUNT") +
theme(plot.title = element_text(face="bold",size=26, hjust = 0.5), axis.title = element_text(face="bold",size = 20), axis.text = element_text(face="bold", size = 20), 
strip.text = element_text(size=16, face="bold.italic")) +
ggtitle(paste("LFD:", paste(unique(final.data$FAO)), ", ", "EU State: ", paste(sort(unique(final.data$Vessel_flag_country)), 
collapse="/"), ", Area: ",  paste(sort(unique(final.data$Area)), collapse="/"), ", Quarter: ",  paste(sort(unique(final.data$Quarter)), collapse="/"), 
", Year: ", paste(unique(final.data$Year),collapse="/")))

plot(p)

if (delta > 1)
{
final.data$LengthClass_bin <- lencat(final.data$LengthClass_cm,w=delta, startcat=0);

Mbin <- max(as.numeric(final.data$LengthClass_bin));

Ubin <- c();

for (k in 1:length(selected.year))
{
U2 <- data.frame(selected.year[k], table(factor(subset(final.data, Year==selected.year[k])$LengthClass_bin, levels=seq(0, M, by=delta))));
names(U2) <- c("year","LengthClass_cm", "freq");
Ubin <- rbind(Ubin,U2)
}

rbin <- max(Ubin$freq)

dev.new();

pbin <- ggplot(final.data, aes(x=LengthClass_cm)) + 
facet_wrap(~Year) +
geom_histogram(data = final.data, aes(x = LengthClass_bin), binwidth = delta, boundary=0, closed="left",  colour="black", fill="turquoise") + 
xlim(0,Mbin)+
ylim(0,rbin)+
labs(title="LFD", x="LENGTH", y = "COUNT") +
annotate(geom="text", x=6*Mbin/7, y=9*rbin/10, label=as.character(paste("bin width = ", delta)), color="blue",size=15) +
theme(plot.title = element_text(face="bold",size=26, hjust = 0.5), axis.title = element_text(face="bold",size = 20), 
axis.text = element_text(face="bold", size = 20), strip.text = element_text(size=20, face="bold.italic")) +
ggtitle(paste("LFD:", paste(unique(final.data$FAO)), ", ", "EU State: ", 
paste(sort(unique(final.data$Vessel_flag_country)), collapse="/"), ", Area: ",  paste(sort(unique(final.data$Area)), collapse="/"), ", Quarter: ",  
paste(sort(unique(final.data$Quarter)), collapse="/"), ", Year: ", paste(sort(unique(final.data$Year)),collapse="/")))

plot(pbin)
}

output.data <- final.data;

}









