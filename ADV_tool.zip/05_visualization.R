####################################################
### Compare two LFDs:
### reference: if TRUE, then a comparison of reference subsample, if FALSE then a comparison with "real world sample"
### delta: if delta>1, then output includs two plots - for delta=1cm and delta>1cm, otherwise only plot for delta=1cm
### data_1 - original sample
### data_2 - subsample   
####################################################


compare_distribution <- function(data_1, data_2, delta=1, important, reference=TRUE)

{

if (missing(important)) 
{
M <- max(data_1$LengthClass_cm);
cl <- seq(0, M, by=1);
important <- c(0:M);
} else
{
M <- max(subset(data_1, LengthClass_cm %in% important)$LengthClass_cm);
cl <- seq(0, M, by=1);
}


U <- data.frame(table(factor(data_1$LengthClass_cm, levels=seq(0, M, by=1))));
names(U) <- c("LengthClass_cm", "freq");
r <- max(U$freq);


dev.new();

p1 <- ggplot(data_1, aes(x=LengthClass_cm)) + 
geom_histogram(data = data_1, aes(x = LengthClass_cm), binwidth = 1, boundary=0, closed="left", colour="black",fill="turquoise") + 
xlim(0,M)+
ylim(0,r)+
annotate("text", label = paste("n =", nrow(data_1)), x = M-20, y = 7/8*r, size = 13, colour = "black", fontface = 4) +
labs(title="ORIGINAL SAMPLE", x="LENGTH", y = "COUNT") +
theme(title = element_text(face="bold",size=19), axis.title = element_text(face="bold",size = 17), axis.text = element_text(face="bold", size = 17), strip.text = element_text(size=20, face="bold.italic")) 


p2 <- ggplot(data_2, aes(x=LengthClass_cm)) + 
geom_histogram(data = data_2, aes(x = LengthClass_cm), binwidth = 1, boundary=0, closed="left", colour="black",fill="lightskyblue1") + 
xlim(0,M)+
ylim(0,r)+
annotate("text", label = paste("n =", nrow(data_2)), x = M-20, y = 7/8*r, size = 13, colour = "black", fontface = 4) +
labs(title=ifelse(reference==TRUE,"REFERENCE SUBSAMPLE", "SUBSAMPLE"), x="LENGTH", y = "COUNT") +
theme(title = element_text(face="bold",size=19), axis.title = element_text(face="bold",size = 17), axis.text = element_text(face="bold", size = 17), strip.text = element_text(size=20, face="bold.italic")) 

library(gridGraphics)

grid.arrange(p1, p2, ncol=2);
top=textGrob(paste("LFD:", paste(unique(data_1$Species_code)), 
", ", 
"LC = ", min(important), ":", max(important), 
", ", 
"EU STATE: ", paste(unique(data_1$Vessel_flag_country), collapse="/"), 
", Area: ",  paste(unique(data_1$Area), collapse="/"), 
", Quarter ", paste(unique(data_1$Quarter), collapse="/"),  
", Year", paste(unique(data_1$Year),collapse="/" ),
"\n"), 
gp=gpar(fontsize=27, font=2));


if (delta>1)

{

LengthClass_cm_delta <- lencat(data_1$LengthClass_cm, w=delta, startcat=0);
LengthClass_cm_delta <- data.frame(LengthClass_cm_delta);  
data_1_d <- cbind(data_1, LengthClass_cm_delta);

LengthClass_cm_delta <- lencat(data_2$LengthClass_cm, w=delta, startcat=0);
LengthClass_cm_delta <- data.frame(LengthClass_cm_delta);  
data_2_d <- cbind(data_2,LengthClass_cm_delta);


Mdelta <- max(data_1_d$LengthClass_cm_delta) + delta;



Udelta <- data.frame(table(factor(data_1_d$LengthClass_cm_delta, levels=seq(0, Mdelta, by=delta))));
names(Udelta) <- c("LengthClass_cm", "freq");
rdelta <- max(Udelta$freq);

dev.new();

p3 <- ggplot(data_1_d, aes(x=LengthClass_cm_delta)) + 
geom_histogram(data = data_1_d, aes(x = LengthClass_cm_delta), binwidth = delta, boundary=0, closed="left", colour="black",fill="turquoise") + 
xlim(0,Mdelta)+
ylim(0,rdelta)+
annotate("text", label = paste("n =", nrow(data_1_d)), x = Mdelta-20, y = 7/8*rdelta, size = 13, colour = "black", fontface = 4) +
#annotate(geom="text", x=M-20, y=7/9*rdelta, label=as.character(paste("bandwidth = ", delta)), color="blue",size=15) +
labs(title="ORIGINAL SAMPLE", x="LENGTH", y = "COUNT") +
theme(title = element_text(face="bold",size=19), axis.title = element_text(face="bold",size = 17), axis.text = element_text(face="bold", size = 17), strip.text = element_text(size=20, face="bold.italic")) 


p4 <- ggplot(data_2_d, aes(x=LengthClass_cm_delta)) + 
geom_histogram(data = data_2_d, aes(x = LengthClass_cm_delta), binwidth = delta, boundary=0, closed="left", colour="black",fill="lightskyblue1") + 
xlim(0,Mdelta)+
ylim(0,rdelta)+
annotate("text", label = paste("n =", nrow(data_2_d)), x = Mdelta-20, y = 7/8*rdelta, size = 13, colour = "black", fontface = 4) +
#annotate(geom="text", x=M-20, y=7/9*rdelta, label=as.character(paste("bandwidth = ", delta)), color="blue",size=15) +
labs(title=ifelse(reference==TRUE,"REFERENCE SUBSAMPLE", "SUBSAMPLE"), x="LENGTH", y = "COUNT") +
theme(title = element_text(face="bold",size=19), axis.title = element_text(face="bold",size = 17), axis.text = element_text(face="bold", size = 17), strip.text = element_text(size=20, face="bold.italic")) 

library(gridGraphics)

grid.arrange(p3, p4, ncol=2); 
top=textGrob(paste("LFD:", paste(unique(data_1$Species_code)), 
", ", 
"LC = ", min(important), ":", max(important), 
", ", 
"EU STATE: ", paste(unique(data_1$Vessel_flag_country), collapse="/"), 
", Area: ",  paste(unique(data_1$Area), collapse="/"), 
", Quarter ", paste(unique(data_1$Quarter), collapse="/"),  
", Year", paste(unique(data_1$Year),collapse="/" ),
"\n"), 
gp=gpar(fontsize=27, font=2));

}



}

