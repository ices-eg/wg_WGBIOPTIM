### This script determines modes and antimodes of dataset
### Inputs and parameters: data in RDB format (data); smoothed - if FALSE, then only all modes/antimodes without smoothing, if TRUE, then all modes/antimodes without smoothing + all modes/antimodes with smoothing; delta - smoothing level; important - important length classes, where robust modes/antimodes should be determined
### Outputs: all modes/antimodes/ranges; smoothed modes/antimodes/ranges; robust modes/antimodes/ranges


findModesAntimodes <- function(dataset, delta = 10, important = NULL) 

{
  
  if (missing(important)) important <- seq(0, max(dataset$Length_class), by=10)

  dataset <- subset(dataset, Length_class %in% important)

year <- sort(unique(dataset$Year))

frequency_length <- function(y) {data.frame(y, table(factor(subset(dataset, Year==y)$Length_class, levels=seq(0, max(dataset[,"Length_class"]), by=10))))%>%
    rename(Year = y, Length_class = Var1)}

table.length.classes.frequency.modes.antimodes <- do.call("rbind", lapply(year, frequency_length))

modes <- c()
antimodes <- c()

## all modes
for (y in year)
{
  
  t.year <- subset(table.length.classes.frequency.modes.antimodes, Year==y)
  
  ind_modes <- NULL
  ind_dips <- NULL
  
    	for ( i in 2:(length(t.year$Freq)-1) )
    	{
    	if ( (t.year$Freq[i] >= t.year$Freq[i-1]) &
    	     t.year$Freq[i] >= t.year$Freq[i+1] ) {
    	ind_modes <- c(ind_modes, i)}
    	}
  modes <- rbind(modes, t.year[c(ind_modes),])
  
## all antimodes
    	for ( j in 2:(length(t.year$Freq)-1) )
    	{
    	if ( t.year$Freq[j] <= t.year$Freq[j-1] &
    	     (t.year$Freq[j] <= t.year$Freq[j+1])) {
    	ind_dips <- c(ind_dips, j)}
    	}
  antimodes <- rbind(antimodes, t.year[c(ind_dips),])
}



  ## modes filtering: remove negligible modes with "low participation/contribution" into distributional shape: all modes (local maximums) which deliver frequency 
  ## less than 5% of maximal frequency (global maximum) are skipped
  ## antimodes filtering: antimodes related to removed modes are removed as well 
  
main_modes <- modes%>%group_by(Year)%>%slice(which.max(Freq))%>%mutate(margin = round(0.05 * Freq))
modes_corrected <- merge(modes, main_modes[, c("Year", "margin")], by="Year", all.x=TRUE)%>%filter(Freq>margin)%>%select(Year, Length_class, Freq)


if (delta>10)
{
  dataset$Length_class_smoothed <- lencat(dataset$Length_class, w = delta, startcat = 0)
  
  frequency_length_bin <- function(y) {data.frame(y, table(factor(subset(dataset, Year==y)$Length_class_smoothed, levels=seq(0, max(dataset[,"Length_class_smoothed"]), by=delta))))%>%
      rename(Year = y, Length_class_smoothed = Var1)}
  
  table.length.classes.frequency.modes.antimodes_bin <- do.call("rbind", lapply(year, frequency_length_bin))
  
  modes_bin <- c()
  antimodes_bin <- c()
  
  ## all modes
  for (y in year)
  {
    
    t.year_bin <- subset(table.length.classes.frequency.modes.antimodes_bin, Year==y)
    
    ind_modes <- NULL
    ind_dips <- NULL
    
    for ( i in 2:(length(t.year_bin$Freq)-1) )
    {
      if ( (t.year_bin$Freq[i] > t.year_bin$Freq[i-1]) &
           t.year_bin$Freq[i] >= t.year_bin$Freq[i+1] ) {
        ind_modes <- c(ind_modes, i)}
    }
    modes_bin <- rbind(modes_bin, t.year_bin[c(ind_modes),])
    
    ## all dips
    for ( j in 2:(length(t.year_bin$Freq)-1) )
    {
      if ( t.year_bin$Freq[j] < t.year_bin$Freq[j-1] &
           (t.year_bin$Freq[j] <= t.year_bin$Freq[j+1])) {
        ind_dips <- c(ind_dips, j)}
    }
    antimodes_bin <- rbind(antimodes_bin, t.year_bin[c(ind_dips),])
  }
  
  
    ## modes filtering: remove negligible modes with "low participation/contribution" into distributional shape: all modes (local maximums) which deliver frequency 
    ## less than 5% of maximal frequency (global maximum) are skipped
    ## antimodes filtering: antimodes related to removed modes are removed as well 
    
    main_modes_bin <- modes_bin%>%group_by(Year)%>%slice(which.max(Freq))%>%mutate(margin = round(0.05 * Freq))
    modes_corrected_bin <- merge(modes_bin, main_modes_bin[, c("Year", "margin")], by="Year", all.x=TRUE)%>%filter(Freq>margin)%>%select(Year, Length_class_smoothed, Freq)
    
    antimodes_corrected_bin <- c()
    
    for (y in year)
    {
      
      modes.year_bin <- subset(modes_corrected_bin, Year==y)
      antimodes.year_bin <- subset(antimodes_bin, Year==y)
      length.class.year_bin <- sort(as.integer(as.character(modes.year_bin$Length_class_smoothed)))
      
      if (length(length.class.year_bin)>1)
      {
      for (i in 1:(length(length.class.year_bin)-1))
      {
        subset.antimodes_bin = subset(antimodes.year_bin, as.integer(as.character(antimodes.year_bin$Length_class_smoothed))>length.class.year_bin[i] & 
                                    as.integer(as.character(antimodes.year_bin$Length_class_smoothed))<length.class.year_bin[i+1])
        if (nrow(subset.antimodes_bin)>1) subset.antimodes.corrected_bin <- subset.antimodes_bin%>%slice(which.min(Freq)) else subset.antimodes.corrected_bin <- subset.antimodes_bin
        
        antimodes_corrected_bin <- rbind(antimodes_corrected_bin, subset.antimodes.corrected_bin)
        
      }
      } else { antimodes_corrected_bin <- rbind(antimodes_corrected_bin, antimodes.year_bin) }
    }
    
    modes_corrected_bin$Type <- "mode"
    antimodes_corrected_bin$Type <- "antimode"
  
  
  cp_bin <- rbind(modes_corrected_bin, antimodes_corrected_bin)%>%arrange(Year, as.integer(as.character(Length_class_smoothed)))
  
  cp_bin <- cp_bin%>%group_by(Year)%>%mutate(Diff = abs(Freq - lag(Freq)))
  cp_bin$Diff <- ifelse(is.na(cp_bin$Diff), cp_bin$Freq, cp_bin$Diff)
  
  
  modes.final_bin <- data.frame(subset(cp_bin, Type=="mode")%>%select(Year, Length_class_smoothed, Freq)%>%rename(Count = Freq))
  antimodes.final_bin <- data.frame(subset(cp_bin, Type=="antimode")%>%select(Year, Length_class_smoothed, Freq)%>%rename(Count = Freq))
  
  range.final_bin <- data.frame(cp_bin%>%rename(Count = Freq)%>%select(Year, Length_class_smoothed, Type, Count, Diff))
  
  
  modes.final_bin.interval <- modes.final_bin%>%rename(Year_smoothed = Year)%>%
    mutate(limit_lower= as.integer(as.character(Length_class_smoothed)), limit_upper = as.integer(as.character(Length_class_smoothed)) + delta)%>%select(Year_smoothed, Length_class_smoothed, limit_lower, limit_upper)
  
  antimodes.final_bin.interval <- antimodes.final_bin%>%rename(Year_smoothed = Year)%>%
    mutate(limit_lower= as.integer(as.character(Length_class_smoothed)), limit_upper = as.integer(as.character(Length_class_smoothed)) + delta)%>%select(Year_smoothed, Length_class_smoothed, limit_lower, limit_upper)
  
  
  
  #### correction of antimodes
  
  antimodes_corrected <- c()
  
  for (y in year)
  {
    
    modes.year <- subset(modes_corrected, Year==y)
    antimodes.year <- subset(antimodes, Year==y)
    length.class.year <- sort(as.integer(as.character(modes.year$Length_class)))
    for (i in 1:(length(length.class.year)-1))
    {
      subset.antimodes = subset(antimodes.year, as.integer(as.character(antimodes.year$Length_class))>length.class.year[i] & 
                                  as.integer(as.character(antimodes.year$Length_class))<length.class.year[i+1])
      if (nrow(subset.antimodes)>1) 
      {
        subset.antimodes$Length_class_smoothed <- lencat(as.numeric(as.character(subset.antimodes$Length_class)), w = delta, startcat = 0)
        subset.antimodes.corrected <- subset.antimodes%>%merge(antimodes.final_bin.interval, by.x=c("Year", "Length_class_smoothed"), by.y=c("Year_smoothed", "Length_class_smoothed"), all.x=TRUE)%>%
          filter(!is.na(limit_lower) & !is.na(limit_upper))%>%slice(which.min(Freq)) 
        subset.antimodes.corrected <- subset.antimodes.corrected[, c("Year", "Length_class", "Freq")]
        
        } else subset.antimodes.corrected <- subset.antimodes[, c("Year", "Length_class", "Freq")]
      
      antimodes_corrected <- rbind(antimodes_corrected, subset.antimodes.corrected)
      
    }
  }
  
  modes_corrected$Type <- "mode"
  antimodes_corrected$Type <- "antimode"


cp <- rbind(modes_corrected, antimodes_corrected)%>%arrange(Year, as.integer(as.character(Length_class)))

cp <- cp%>%group_by(Year)%>%mutate(Diff = abs(Freq - lag(Freq)))
cp$Diff <- ifelse(is.na(cp$Diff), cp$Freq, cp$Diff)


modes.final <- data.frame(subset(cp, Type=="mode")%>%select(Year, Length_class, Freq)%>%rename(Count = Freq))
antimodes.final <- data.frame(subset(cp, Type=="antimode")%>%select(Year, Length_class, Freq)%>%rename(Count = Freq))

range.final <- data.frame(cp%>%rename(Count = Freq)%>%select(Year, Length_class, Type, Count, Diff))


####################################

  
  
  

  
  modes_robust <- modes.final%>%mutate(Length_class = as.integer(as.character(Length_class)))%>%
    fuzzy_left_join(modes.final_bin.interval, by = c("Year" = "Year_smoothed", "Length_class" = "limit_lower", "Length_class" = "limit_upper"), match_fun = list(`==`, `>=`, `<`))%>%
    filter(!is.na(Year_smoothed))%>%
    group_by(Year_smoothed, Length_class_smoothed )%>%
    slice_max(Count)%>%
    ungroup()%>%
    distinct(Count, Year_smoothed, Length_class_smoothed, .keep_all = TRUE)%>% ## only one (the first one) inside the same Length_class_smoothed/Year
    select(Year, Length_class, Count)
  
  antimodes_robust <- antimodes.final%>%mutate(Length_class = as.integer(as.character(Length_class)))%>%
    fuzzy_left_join(antimodes.final_bin.interval, by = c("Year" = "Year_smoothed", "Length_class" = "limit_lower", "Length_class" = "limit_upper"), match_fun = list(`==`, `>=`, `<`))%>%
    filter(!is.na(Year_smoothed))%>%
    group_by(Year_smoothed, Length_class_smoothed )%>%
    slice_min(Count)%>%
    ungroup()%>%
    distinct(Count, Year_smoothed, Length_class_smoothed, .keep_all = TRUE)%>% ## only one (the first one) inside the same Length_class_smoothed/Year
    select(Year, Length_class, Count)
  
  modes_robust$Type <- "mode"
  antimodes_robust$Type <- "antimode"
  
  cp_robust <- rbind(modes_robust, antimodes_robust)%>%arrange(Year, as.integer(as.character(Length_class)))
  
  cp_robust <- cp_robust%>%group_by(Year)%>%mutate(Diff = abs(Count - lag(Count)))
  cp_robust$Diff <- ifelse(is.na(cp_robust$Diff), cp_robust$Count, cp_robust$Diff)
  
  
  range.final_robust <- data.frame(cp_robust%>%select(Year, Length_class, Type, Count, Diff))

  
  modes.final_robust <- data.frame(subset(cp_robust, Type=="mode")%>%select(Year, Length_class, Count))
  antimodes.final_robust <- data.frame(subset(cp_robust, Type=="antimode")%>%select(Year, Length_class, Count))
  
  
  return(list(modes = modes.final, antimodes = antimodes.final, range = range.final, 
              modes_smoothed = modes.final_bin,  antimodes_smoothed = antimodes.final_bin, range_smoothed = range.final_bin,
              modes_robust = modes.final_robust,  antimodes_robust = antimodes.final_robust, range_robust = range.final_robust))
  
  
} else
{
  
  #### correction of antimodes
  
  antimodes_corrected <- c()
  
  for (y in year)
  {
    
    modes.year <- subset(modes_corrected, Year==y)
    antimodes.year <- subset(antimodes, Year==y)
    length.class.year <- sort(as.integer(as.character(modes.year$Length_class)))
    for (i in 1:(length(length.class.year)-1))
    {
      subset.antimodes = subset(antimodes.year, as.integer(as.character(antimodes.year$Length_class))>length.class.year[i] & 
                                  as.integer(as.character(antimodes.year$Length_class))<length.class.year[i+1])
      if (nrow(subset.antimodes)>1) subset.antimodes.corrected <- subset.antimodes%>%slice(which.min(Freq)) else subset.antimodes.corrected <- subset.antimodes
      
      antimodes_corrected <- rbind(antimodes_corrected, subset.antimodes.corrected)
      
    }
  }
  
  modes_corrected$Type <- "mode"
  antimodes_corrected$Type <- "antimode"


cp <- rbind(modes_corrected, antimodes_corrected)%>%arrange(Year, as.integer(as.character(Length_class)))

cp <- cp%>%group_by(Year)%>%mutate(Diff = abs(Freq - lag(Freq)))


modes.final <- data.frame(subset(cp, Type=="mode")%>%select(Year, Length_class, Freq)%>%rename(Count = Freq))
antimodes.final <- data.frame(subset(cp, Type=="antimode")%>%select(Year, Length_class, Freq)%>%rename(Count = Freq))

range.final <- data.frame(cp%>%rename(Count = Freq)%>%select(Year, Length_class, Type, Count, Diff))


####################################

return(list(modes = modes.final, antimodes = antimodes.final, range = range.final,
            modes_smoothed = NULL,  antimodes_smoothed = NULL, range_smoothed = NULL,
            modes_robust = modes.final,  antimodes_robust = antimodes.final, range_robust = range.final))
}


}

