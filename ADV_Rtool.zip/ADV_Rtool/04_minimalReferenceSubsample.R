#### This script describes iterative subsampling procedure for reference subsample ("worst case") construction
#### Inputs and parameters: data - input data set; delta - parameter defining smoothing level; theta - parameter defining amplitude ratio; epsion - parameter defining tolerated critical poits shift;
#### gamma - parameter defining minimally permitted number per length class; important - defined important length classes
#### Ouputs: data set representing reference subsample + 2 histogram plots comparing original data set and reference subsample (with bin width = 1 cm and bin width = delta > 1 cm)

subsampling <- function(dataset, n_s = 1, delta = 10, theta=0.9, epsilon = 0, gamma = 0.1, important = NULL)
{

if (missing(important)) important <- seq(0, max(dataset$Length_class), by = 10)
  
dataset <- subset(dataset, Length_class %in% important)

year <- sort(unique(dataset$Year))

frequency_length <- function(y) {data.frame(y, table(factor(subset(dataset, Year==y)$Length_class, levels=seq(0, max(dataset[,"Length_class"]), by=10))))%>%
    rename(Year = y, Length_class = Var1)}

table.length.classes.frequency.original <- do.call("rbind", lapply(year, frequency_length))
table.length.classes.frequency.original <- table.length.classes.frequency.original%>%group_by(Year)%>%mutate(sum_Freq = sum(Freq))

## minimal required number in length class by downsampling, relative under gamma<1 or absolute under gamma>=1

if (gamma < 1) table.length.classes.frequency.original$minimal_number_per_length_class <- 
  ifelse(table.length.classes.frequency.original$Freq <= floor(table.length.classes.frequency.original$sum_Freq*0.01), 0, floor(gamma * table.length.classes.frequency.original$Freq)) else 
    table.length.classes.frequency.original$minimal_number_per_length_class <- 
  ifelse(table.length.classes.frequency.original$Freq <= floor(table.length.classes.frequency.original$sum_Freq*0.01), 0, pmin(gamma, table.length.classes.frequency.original$Freq))

min_number <- table.length.classes.frequency.original%>%select(Year, Length_class, minimal_number_per_length_class)

distributional.shape_original <- findModesAntimodes(dataset, delta = delta, important = important)

dataset_original <- merge(dataset, table.length.classes.frequency.original, by=c("Year", "Length_class"), all.x=TRUE)

### master-table original
dataset_original <- dataset_original%>%
  merge(distributional.shape_original$modes_robust%>%group_by(Year)%>%summarize(N_modes_original = n()), by="Year", all.x=TRUE)%>%
  merge(distributional.shape_original$antimodes_robust%>%group_by(Year)%>%summarize(N_antimodes_original = n()), by="Year", all.x=TRUE)%>%
  merge(distributional.shape_original$modes_robust%>%select("Year", "Length_class")%>%group_by(Year)%>%mutate(col_name = str_c("mode_original_", row_number()))%>%
          pivot_wider(names_from = col_name, values_from = Length_class), by="Year", all.x=TRUE)%>%
  merge(distributional.shape_original$antimodes_robust%>%select("Year", "Length_class")%>%group_by(Year)%>%mutate(col_name = str_c("antimode_original_", row_number()))%>%
          pivot_wider(names_from = col_name, values_from = Length_class), by="Year", all.x=TRUE)%>%
  merge(subset(distributional.shape_original$range_robust, !is.na(Diff))%>%select("Year", "Diff")%>%group_by(Year)%>%mutate(col_name = str_c("range_original_", row_number()))%>%
          pivot_wider(names_from = col_name, values_from = Diff), by="Year", all.x=TRUE)


dataset_original$id <- c(1:nrow(dataset_original))

cat("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%", fill=TRUE)
cat("", fill=TRUE)

cat(paste0("Years in original dataset: ", paste(sort(unique(dataset_original$Year)), collapse =",")), fill=TRUE)
cat(paste0("Nrow in original dataset: ", nrow(dataset_original)), fill=TRUE)
Nrow_per_Year <- data.frame(dataset_original%>%group_by(Year)%>%summarize(Nrow_Year = n()))
print(Nrow_per_Year, row.names = FALSE)

i <- 1
dataset_i_1 <- dataset_original


subsample_final <- c()

repeat
{
  
    sample_i <- dataset_i_1%>%filter(Freq>0 & Freq>minimal_number_per_length_class)%>%group_by(Year, Length_class)%>%slice_sample(n = n_s)
    
    
    dataset_i <- setdiff(dataset_i_1, sample_i)
    
    frequency_length_i <- function(y) {data.frame(y, table(factor(subset(dataset_i, Year==y)$Length_class, levels=seq(0, max(dataset_i[,"Length_class"]), by=10))))%>%
        rename(Year = y, Length_class = Var1)}
    
    table.length.classes.frequency.i <- do.call("rbind", lapply(year, frequency_length_i))
    
    
    distributional.shape_i <- findModesAntimodes(dataset_i, delta = delta, important = important)
    
    
    dataset_i <- merge(dataset_i[!(colnames(dataset_i) %in% c("Freq"))], table.length.classes.frequency.i, by=c("Year", "Length_class"), all.x=TRUE)
    
    
    dataset_i <- dataset_i[!(colnames(dataset_i) %in% c("N_modes_i", "N_antimodes_i"))]%>%
      merge(distributional.shape_i$modes_robust%>%group_by(Year)%>%summarise(N_modes_i = n()), by="Year", all.x=TRUE)%>%
      merge(distributional.shape_i$antimodes_robust%>%group_by(Year)%>%summarise(N_antimodes_i = n()), by="Year", all.x=TRUE)%>%
      merge(distributional.shape_i$modes_robust%>%select("Year", "Length_class")%>%group_by(Year)%>%mutate(col_name = str_c("mode_i_", row_number()))%>%
              pivot_wider(names_from = col_name, values_from = Length_class), by="Year", all.x=TRUE)%>%
      merge(distributional.shape_i$antimodes_robust%>%select("Year", "Length_class")%>%group_by(Year)%>%mutate(col_name = str_c("antimode_i_", row_number()))%>%
              pivot_wider(names_from = col_name, values_from = Length_class), by="Year", all.x=TRUE)%>%
      merge(subset(distributional.shape_i$range_robust, !is.na(Diff))%>%select("Year", "Diff")%>%group_by(Year)%>%mutate(col_name = str_c("range_i_", row_number()))%>%
              pivot_wider(names_from = col_name, values_from = Diff), by="Year", all.x=TRUE)
    
    
    number_of_modes_antimodes_broken_condition_i <- dataset_i%>%group_by(Year)%>%filter(N_modes_i!=N_modes_original | N_antimodes_i!=N_antimodes_original)
    C1 <- (nrow(number_of_modes_antimodes_broken_condition_i)>0)
    
   if(!C1) ### to check the location makes sense if the number of modes/antimodes remains the same
   {
    original_modes <- grep('^mode_original', names(dataset_i), value = TRUE)
    original_antimodes <- grep('^antimode_original', names(dataset_i), value = TRUE)
    
    i_modes <- grep('^mode_i', names(dataset_i), value = TRUE)
    i_antimodes <- grep('^antimode_i', names(dataset_i), value = TRUE)

    dataset_i[paste0(original_modes, '.diff')] <- abs(dataset_i[original_modes] - dataset_i[i_modes])
    dataset_i[paste0(original_antimodes, '.diff')] <- abs(dataset_i[original_antimodes] - dataset_i[i_antimodes])
    changed_location_of_modes_antimodes_condition_i <- dataset_i%>%group_by(Year)%>%filter(if_any(ends_with(".diff"), ~ . > epsilon))
    unique_differences <- changed_location_of_modes_antimodes_condition_i%>%select(Year, ends_with(".diff"))%>%distinct()%>%group_by(Year)%>%
      mutate(Differences = paste(c_across(everything()), collapse=";"))%>%select(Year, Differences)
    C2 <- (nrow(changed_location_of_modes_antimodes_condition_i)>0 & C1==FALSE)
   }
    
    if(!C1) ### to check the range makes sense if the number of modes/antimodes remains the same
    {
      original_ranges <- grep('^range_original', names(dataset_i), value = TRUE)
      
      i_ranges <- grep('^range_i', names(dataset_i), value = TRUE)
      
      dataset_i[paste0(original_ranges, '.ratio')] <-  round(dataset_i[i_ranges]/dataset_i[original_ranges], 4)
      changed_ranges_of_modes_antimodes_condition_i <- dataset_i%>%group_by(Year)%>%filter(if_any(ends_with(".ratio"), ~ . < theta))
      unique_ratios <- changed_ranges_of_modes_antimodes_condition_i%>%select(Year, ends_with(".ratio"))%>%distinct()%>%group_by(Year)%>%
        mutate(Ratios = paste(c_across(everything()), collapse=";"))%>%select(Year, Ratios)
      C3 <- (nrow(changed_ranges_of_modes_antimodes_condition_i)>0 & C1==FALSE)
    }

  
    minimal_number_of_measurements_i <- dataset_i%>%group_by(Year)%>%filter(all(Freq==0) | any(Freq<=minimal_number_per_length_class))
    C4 <- nrow(minimal_number_of_measurements_i > 0)
    
    
    #### if any of conditions is true
    
    if (any(C1, C2, C3, C4))
    {
      cat("", fill=TRUE)
      cat("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%", fill=TRUE)
      cat("", fill=TRUE)
      
      
      if (C1)
      {
      remove_subsample <- number_of_modes_antimodes_broken_condition_i
      y_i <- unique(remove_subsample$Year)
      
      cat(paste0("YEAR ", paste(y_i, collapse =","), ":"), fill=TRUE)
      cat("NUMBER OF MODES/ANTIMODES HAS CHANGED. SUBSAMPLING HAS STOPPED.", fill=TRUE)
      D <- merge(subset(distributional.shape_original$modes_robust, Year %in% y_i)%>%group_by(Year)%>%summarise(N_Modes_original = n()), 
                 subset(distributional.shape_i$modes_robust, Year %in% y_i)%>%group_by(Year)%>%summarise(N_Modes = n()), by="Year", all.x=TRUE)%>%
        merge(subset(distributional.shape_original$antimodes_robust, Year %in% y_i)%>%group_by(Year)%>%summarise(N_Antimodes_original = n()), by="Year", all.x=TRUE)%>%
        merge(subset(distributional.shape_i$antimodes_robust, Year %in% y_i)%>%group_by(Year)%>%summarise(N_Antimodes = n()), by="Year", all.x=TRUE)
      cat("", fill=TRUE)
      cat("CHANGES IN NUMBER OF MODES/ANTIMODES CAUSED A SUBSAMPLING STOP:", fill=TRUE)
      print(D, row.names = FALSE)
      }
      
      if (C2)
      {
        remove_subsample <- changed_location_of_modes_antimodes_condition_i
        y_i <- unique(remove_subsample$Year)
        
        cat(paste0("YEAR ", paste(y_i, collapse =","), ":"), fill=TRUE)
        cat("LOCATION OF MODES/ANTIMODES DEFINED BY PARAMETER epsilon HAS CHANGED. SUBSAMPLING HAS STOPPED.", fill=TRUE)
        D <- merge(subset(distributional.shape_original$modes_robust, Year %in% y_i)%>%group_by(Year)%>%summarise(Modes_original = paste(Length_class, collapse=",")), 
                   subset(distributional.shape_i$modes_robust, Year %in% y_i)%>%group_by(Year)%>%summarise(Modes = paste(Length_class, collapse=",")), by="Year", all.x=TRUE)%>%
          merge(subset(distributional.shape_original$antimodes_robust, Year %in% y_i)%>%group_by(Year)%>%summarise(Antimodes_original = paste(Length_class, collapse=",")), by="Year", all.x=TRUE)%>%
          merge(subset(distributional.shape_i$antimodes_robust, Year %in% y_i)%>%group_by(Year)%>%summarise(Antimodes = paste(Length_class, collapse=",")), by="Year", all.x=TRUE)%>%
          merge(unique_differences, by="Year", all.x=TRUE)
        cat("", fill=TRUE)
        cat("CHANGES IN LOCATION OF MODES/ANTIMODES CAUSED A SUBSAMPLING STOP:", fill=TRUE)
        print(D, row.names = FALSE)
      }
      
      if (C3)
      {
        remove_subsample <- changed_ranges_of_modes_antimodes_condition_i
        y_i <- unique(remove_subsample$Year)
        
        cat(paste0("YEAR ", paste(y_i, collapse =","), ":"), fill=TRUE) 
        cat("RANGES BETWEEN MODES/ANTIMODES DEFINED BY PARAMETER theta HAS CHANGED. SUBSAMPLING HAS STOPPED.", fill=TRUE)
        D <- merge(subset(distributional.shape_original$range_robust, Year %in% y_i & !is.na(Diff))%>%group_by(Year)%>%summarise(Ranges_original = paste(Diff, collapse=",")), 
                   subset(distributional.shape_i$range_robust, Year %in% y_i & !is.na(Diff))%>%group_by(Year)%>%summarise(Ranges = paste(Diff, collapse=",")), by="Year", all.x=TRUE)%>%
          merge(unique_ratios, by="Year", all.x=TRUE)
        cat("", fill=TRUE)
        cat("CHANGES IN RANGES OF MODES/ANTIMODES CAUSED A SUBSAMPLING STOP:", fill=TRUE)
        print(D, row.names = FALSE)
      }
      
      if (C4)
      {
        remove_subsample <- minimal_number_of_measurements_i
        y_i <- unique(remove_subsample$Year)
        
        cat(paste0("YEAR ", paste(y_i, collapse =","), ":"), fill=TRUE)
        cat("MINIMAL NUMBER OF MEASUREMENTS IN EACH CLASS DEFINED BY PARAMETER gamma WAS ACHIEVED. SUBSAMPLING HAS STOPPED.", fill=TRUE)
        original.frequency <- table.length.classes.frequency.original%>%rename(Freq_original = Freq)%>%select(Year, Length_class, Freq_original, minimal_number_per_length_class)
        D <- subset(table.length.classes.frequency.i, Year %in% y_i)%>%
          merge(subset(original.frequency, Year %in% y_i), by=c("Year", "Length_class"), all.x=TRUE)%>%
          rename(Count_per_Length_class = Freq, Minimal_Count_per_Length_class = minimal_number_per_length_class)%>%
          filter(Count_per_Length_class<=Minimal_Count_per_Length_class & Minimal_Count_per_Length_class>0 & Count_per_Length_class>0)%>%select(Year, Length_class, Count_per_Length_class, Minimal_Count_per_Length_class)
        cat("", fill=TRUE)
        cat("CHANGES IN FREQUENCY TABLE CAUSED A SUBSAMPLING STOP:", fill=TRUE)
        print(D, row.names = FALSE)
      }
      

      #### goes to final subsample
      subsample_i <- subset(dataset_i_1[, names(dataset_original)], Year %in% y_i)
      
      subsample_final <- rbind(subsample_final, subsample_i)
      
      #### continue subsampling
      dataset_i <- setdiff(dataset_i[, names(dataset_original)], remove_subsample[, names(dataset_original)])
      

      dataset_i_1 <- dataset_i[, names(dataset_original)]
      
      if (nrow(dataset_i)==0) 
      {
      cat("", fill=TRUE)
      cat("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%", fill=TRUE)
      cat("", fill=TRUE)
      cat(paste0("Years in final subsampled dataset: ", paste0(sort(unique(subsample_final$Year)), collapse =",")), fill=TRUE)
      cat(paste0("Nrow in final subsampled dataset: ", nrow(subsample_final)), fill=TRUE)
      Nrow_per_Year <- data.frame(subsample_final%>%group_by(Year)%>%summarize(Nrow_Year = n()))
      print(Nrow_per_Year, row.names = FALSE)
      
      break
      }
      
      
   } else dataset_i_1 <- dataset_i[, names(dataset_original)]
     
    
    i <- i + 1
    
    
}

cat("", fill=TRUE)
cat("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%", fill=TRUE)


return(list(referenceSubsample = subsample_final, epsilon = epsilon, theta = theta, important = important))


}