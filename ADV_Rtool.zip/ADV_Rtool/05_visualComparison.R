####################################################
### Compare two LFDs:
### reference: if TRUE, then reference subsample, if FALSE then "real world" sample
### delta: if delta > 10, then output includs two plots - for delta = 10 mm and delta = 10 mm, otherwise only plot for delta = 10 cm
### x1 - original sample
### dataset2 - subsample   
####################################################


visualComparison <- function(dataset1, dataset2, delta = 10, important = NULL, reference_subsample = TRUE)

{

  if (missing(important)) important <- seq(0, max(dataset1$Length_class), by = 10)
  
  dataset1 <- subset(dataset1, Length_class %in% important)
  dataset1$Data <- "original sample"
  
  dataset2 <- subset(dataset2, Length_class %in% important)
  if (reference_subsample) dataset2$Data <- "reference subsample" else dataset2$Data <- "subsample"
  
  dataset2 <- dataset2%>%select(names(dataset1))
  
  
  x <- rbind(dataset1, dataset2)
  
  x <- x%>%group_by(Year, Data)%>%mutate(n_in_year_type = n()) 
  
  
  year <- sort(unique(x$Year))
  
  M <- max(x$Length_class)
  
  
  frequency_length_comparison <- function(y) {data.frame(y, table(factor(subset(x, Year==y & Data=="original sample")$Length_class, levels=seq(0, max(x[,"Length_class"]), by = 10))))%>%
      rename(Year = y, Length_class = Var1)}
  
  table.length.classes.frequency.comparison <- do.call("rbind", lapply(year, frequency_length_comparison))

  
  r <- max(table.length.classes.frequency.comparison$Freq)


p <- ggplot(x, aes(x = Length_class, fill = Data)) + 
  facet_wrap(~ Year + Data, ncol = 2) +
  geom_histogram(data = x, aes(x = Length_class), binwidth = 10, boundary = 0, closed = "left",  colour = "black") + 
  xlim(0,M)+
  ylim(0,r)+
  labs(x="LENGTH (mm, binwidth = 10 mm)", y = "COUNT") +
  theme(plot.title = element_text(face="bold", size=15, hjust = 0.5, color = "deepskyblue3"), 
        plot.subtitle = element_text(face="bold", size=12, hjust = 0.5),
        axis.title = element_text(face="bold", size = 14), 
        axis.text = element_text(face="bold", size = 12),
        text = element_text(size = 12),
        strip.text = element_text(size=15, face="bold.italic"),
        legend.position="none") +
  ggtitle(label = paste0("Species: ", paste(sort(unique(x$FAO)), collapse=",")), 
          subtitle = paste0(paste0("Area: ",  paste(sort(unique(x$Area)), collapse=",")), "\n",
                            "Quarter: ",  paste(sort(unique(x$Quarter)), collapse=","))) +
  geom_text(x= M/10, y= 9/10*r, label = paste0("n = ", x$n_in_year_type), color = "darkblue", fontface = "bold") + 
  scale_fill_manual(values=c("original sample" = "deepskyblue1","reference subsample" = "yellowgreen","subsample" = "tomato1"))

plot(p)

if (delta > 10)
{
  x$Length_class_bin <- lencat(x$Length_class, w = delta, startcat = 0)
  
  Mbin <- max(x$Length_class_bin)
  
  frequency_length_comparison_bin <- function(y) {data.frame(y, table(factor(subset(x, Year==y & Data=="original sample")$Length_class_bin, levels=seq(0, Mbin, by=delta))))%>%
      rename(Year = y, Length_class_bin = Var1)}
  
  table.length.classes.frequency.comparison.bin <- do.call("rbind", lapply(year, frequency_length_comparison_bin))
  
  rbin <- max(table.length.classes.frequency.comparison.bin$Freq)
  
p <- ggplot(x, aes(x = Length_class_bin, fill = Data)) + 
  facet_wrap(~ Year + Data, ncol = 2) +
  geom_histogram(data = x, aes(x = Length_class_bin), binwidth = delta, boundary = 0, closed = "left",  colour="black") + 
  xlim(0,Mbin)+
  ylim(0,rbin)+
  labs(x = paste0("LENGTH (mm, binwidth = ", delta, " mm)"), y = "COUNT") +
  theme(plot.title = element_text(face="bold", size=15, hjust = 0.5, color = "deepskyblue3"), 
        plot.subtitle = element_text(face="bold", size=12, hjust = 0.5),
        axis.title = element_text(face="bold", size = 14), 
        axis.text = element_text(face="bold", size = 12),
        text = element_text(size = 12),
        strip.text = element_text(size=15, face="bold.italic"),
        legend.position="none") +
  ggtitle(label = paste0("Species: ", paste(sort(unique(x$FAO)), collapse=",")), 
          subtitle = paste0(paste0("Area: ",  paste(sort(unique(x$Area)), collapse=",")), "\n",
                            "Quarter: ",  paste(sort(unique(x$Quarter)), collapse=","))) +
  geom_text(x= Mbin/10, y= 9/10*rbin, label = paste0("n = ", x$n_in_year_type), color = "darkblue", fontface = "bold") + 
  scale_fill_manual(values=c("original sample" = "deepskyblue1","reference subsample" = "yellowgreen","subsample" = "tomato1"))

plot(p)
}



}

