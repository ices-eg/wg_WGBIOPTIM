#### The script defines original data set.
#### Inputs: HL, HH and SL tables, as well as selected species, country, metier, year, quarter etc., and also desired (if any) bin width = delta in mm
#### Outputs: desired data set + 2 histogram plots (with bin width = 10 mm (1 cm) and bin width = delta > 10 mm (1 cm))
#### Remarks: input data could be in DATRAS format as well, as alternative format - expand to surveys?
# install_github("ices-tools-prod/icesVocab")




setData <- function(dataset, species, year, quarter, area, delta=10)

{

if (missing(species))     stop("Please provide species FAO.")

WORMS <- getCodeList("SpecWoRMS")[,c("Key","Description")]
names(WORMS) <- c("ID","latin_name")
	
FAO <- getCodeList("SpecASFIS")[,c("Key","Description")]
names(FAO) <- c("FAO","latin_name")


### Extract tables

HL <- dataset$HL
SL <- dataset$SL
HH <- dataset$HH

HL <- merge(HL, WORMS, by.x="Species", by.y="ID", all.x=TRUE)
HL <- merge(HL, FAO, by="latin_name", all.x=TRUE)

HH$Month <- as.numeric(substr(HH$Date, 6, 7)) 
HH$Quarter <- ifelse(HH$Month %in% 1:3, 1, ifelse(HH$Month %in% 4:6, 2, ifelse(HH$Month %in% 7:9, 3, 4)))

################ Final data set species consists of combination of HL, SL and HH, might be extended for CA #####

HLSL <- merge(HL[names(HL)!="Record_type"], SL[names(SL)!="Record_type"], 
              by=c("Year","Landing_country", "Vessel_flag_country", "Sampling_type", "Project",
                   "Trip_number","Station_number","Species", "Catch_category", "Landing_category", 
                   "Comm_size_cat_scale", "Comm_size_cat", "Subsampling_category", "Sex"), 
              all.x=TRUE)

HLSLHH <- merge(HLSL, HH[names(HH)!="Record_type"], by=c("Year","Trip_number","Station_number","Project","Vessel_flag_country", "Landing_country","Sampling_type"), 
                all.x=TRUE)

##### Choice of year, if any ############

if (!(missing(year))) HLSLHH <- subset(HLSLHH, Year %in% year)

##### Choice of quarter, if any ############

if (!(missing(quarter))) HLSLHH <- subset(HLSLHH, Quarter %in% quarter)

##### Choice of area, if any ############

if (!(missing(area))) HLSLHH <- subset(HLSLHH, Area %in% area)

##### Choice of species #################

HLSLHH <- subset(HLSLHH, FAO %in% species)

###############################################################

if (nrow(HLSLHH)==0) stop("This dataset is empty.")

###### Data ordering/cleaning ##################################

year <- sort(unique(HLSLHH$Year))
quarter <- sort(unique(HLSLHH$Quarter))


#########################################################################################################################################################################
######## Raising at haul level ########################################################################################################################
#########################################################################################################################################################################

HLSLHH$Subsample_weight <- ifelse(HLSLHH$Subsample_weight==0 & HLSLHH$Number_at_length>0, HLSLHH$Weight, HLSLHH$Subsample_weight);

HLSLHH$NoAtLength_Raised_to_Haul <- floor(as.numeric(HLSLHH$Number_at_length)*as.numeric(HLSLHH$Weight)/as.numeric(HLSLHH$Subsample_weight))


################ Extracting data: one row = one fish  ################################

final.data <- expandRows(HLSLHH, "NoAtLength_Raised_to_Haul")

final.data$n_in_row <- 1

final.data <- final.data%>%group_by(Year)%>%mutate(n_in_year = n())



##### Binwidth ############

if (missing(delta)) delta <- 10

if (delta<10) stop("The smallest possible value of delta is 10 mm (1 cm).") 

################ Plot ###################

M <- max(final.data$Length_class)

frequency_length <- function(x) {data.frame(x, table(factor(subset(final.data, Year==x)$Length_class, levels=seq(0, M, by=10))))%>%
    rename(Year = x, Length_class = Var1)}

table.length.classes.frequency <- do.call("rbind", lapply(year, frequency_length))

r <- max(table.length.classes.frequency$Freq)


#dev.new()

p <- ggplot(final.data, aes(x = Length_class)) + 
facet_wrap(~ Year) +
geom_histogram(data = final.data, aes(x = Length_class), binwidth = 10, boundary=0, closed="left",  colour="black",fill="deepskyblue1") + 
xlim(0,M)+
ylim(0,r)+
labs(x="LENGTH (mm, binwidth = 10 mm)", y = "COUNT") +
theme(plot.title = element_text(face="bold", size=15, hjust = 0.5, color = "deepskyblue3"), 
      plot.subtitle = element_text(face="bold", size=12, hjust = 0.5),
      axis.title = element_text(face="bold", size = 14), 
      axis.text = element_text(face="bold", size = 12),
      text = element_text(size = 12),
strip.text = element_text(size=15, face="bold.italic")) +
  ggtitle(label = paste0("Species: ", paste(sort(unique(final.data$FAO)), collapse=",")), 
          subtitle = paste0(paste0("Area: ",  paste(sort(unique(final.data$Area)), collapse=",")), "\n",
                           "Quarter: ",  paste(sort(unique(final.data$Quarter)), collapse=","))) +
  geom_text(x= M/10, y= 9/10*r, label = paste0("n = ", final.data$n_in_year), color = "darkblue", fontface = "bold")


plot(p)

if (delta > 10)
{
final.data$Length_class_bin <- lencat(final.data$Length_class, w = delta, startcat = 0)

Mbin <- max(final.data$Length_class_bin)

frequency_length_bin <- function(x) {data.frame(x, table(factor(subset(final.data, Year==x)$Length_class_bin, levels=seq(0, Mbin, by=delta))))%>%
    rename(Year = x, Length_class_bin = Var1)}

table.length.classes.frequency.bin <- do.call("rbind", lapply(year, frequency_length_bin))

rbin <- max(table.length.classes.frequency.bin$Freq)

pbin <- ggplot(final.data, aes(x = Length_class_bin)) + 
facet_wrap(~Year) +
geom_histogram(data = final.data, aes(x = Length_class_bin), binwidth = delta, boundary=0, closed="left",  colour="black", fill="deepskyblue1") + 
xlim(0,Mbin)+
ylim(0,rbin)+
labs(x=paste0("LENGTH (mm, binwidth = ", delta, " mm)"), y = "COUNT") +
theme(plot.title = element_text(face="bold", size=15, hjust = 0.5, color = "deepskyblue3"), 
      plot.subtitle = element_text(face="bold", size=12, hjust = 0.5),
      axis.title = element_text(face="bold", size = 14), 
axis.text = element_text(face="bold", size = 12), strip.text = element_text(size=15, face="bold.italic")) +
  ggtitle(label = paste0("Species: ", paste(sort(unique(final.data$FAO)), collapse=",")), 
          subtitle = paste0(paste0("Area: ",  paste(sort(unique(final.data$Area)), collapse=",")), "\n",
                            "Quarter: ",  paste(sort(unique(final.data$Quarter)), collapse=","))) + 
  geom_text(x= Mbin/10, y= 9/10*rbin, label = paste0("n = ", final.data$n_in_year), color = "darkblue", fontface = "bold")
plot(pbin)
}

output.data <- final.data;

}









