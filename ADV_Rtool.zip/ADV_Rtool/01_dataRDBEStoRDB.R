### x: zip-file of RDBES tables

dataRDBEStoRDB <- function(x)

{
  
  TR_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Vessel_length", "Vessel_power", "Vessel_size", "Vessel_type", "Harbour", 
                    "Number_of_hauls", "Days_at_sea", "Vessel_identifier", "Sampling_country", "Sampling_method");
  
  HL_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Station_number","Species",     
                    "Catch_category","Landing_category","Comm_size_cat_scale","Comm_size_cat","Subsampling_category","Sex","Individual_sex","Length_class",
                    "Number_at_length");
  
  HH_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Station_number",
                    "Fishing_validity","Aggregation_level","Catch_registration","Species_registration","Date","Time","Fishing_duration",
                    "Pos_Start_Lat_dec","Pos_Start_Lon_dec","Pos_Stop_Lat_dec","Pos_Stop_Lon_dec","Area","Statistical_rectangle","Sub_polygon",
                    "Main_fishing_depth","Main_water_depth","FAC_National","FAC_EC_lvl5","FAC_EC_lvl6","Gear_type","Mesh_size","Selection_device",
                    "Mesh_size_selection_device")
  
  SL_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Station_number","Species",
                    "Catch_category","Landing_category","Comm_size_cat_scale","Comm_size_cat","Subsampling_category","Sex","Weight","Subsample_weight","Length_code")
  
  CA_rdb.names <- c("Record_type","Sampling_type","Landing_country","Vessel_flag_country","Year","Project","Trip_number","Station_number",
                    "Quarter","Month","Species", "Sex","Catch_category","Landing_category","Comm_size_cat_scale","Comm_size_cat","Stock","Area","Statistical_rectangle",
                    "Sub_polygon","Length_class","Age","Single_fish_number","Length_code","Aging_method","Age_plus_group","Otolith_weight","Otolith_side","Weight",
                    "Maturity_staging_method","Maturity_scale","Maturity_stage")
  
  #### unzip data, to have CS tables. Fields with ending with "id" and having only NAs, will be deleted
  
  all_files <- as.character(unzip(x, list = TRUE)$Name)
  
  CS.tables <- c("Design", "SamplingDetails", 
                 "VesselSelection", "FishingTrip", 
                 "OnshoreEvent", "LandingEvent", 
                 "FishingOperation", "SpeciesSelection", 
                 "Sample", "FrequencyMeasure",
                 "BiologicalVariable",
                 "VesselDetails", "IndividualSpeciesInSpeciesList")
  
  for (tab in CS.tables)
  {
    if (any(str_detect(all_files, tab)))
    {
      assign(tab, read.csv(unz(x, 
                               all_files[str_detect(all_files, tab)]), header = TRUE, sep=",")%>%
        dplyr::select(-(ends_with("id") & where(~ all(is.na(na_if(as.character(.x), "")))))))
    }
  }




	SAtable_for_length <- subset(Sample, SAlowerHierarchy %in% c("A","B"))
	SAtable_for_age <- subset(Sample, SAlowerHierarchy %in% c("A","B","C"))

	DEtable <- Design
	
	selected_upperHierarchy <- unique(DEtable$DEhierarchy)
	
	cat("Upper hierarchy of the data: ", selected_upperHierarchy, fill=TRUE)

	if (selected_upperHierarchy %in% c(1, 5))
	{
	FTtable <- FishingTrip[,!(names(FishingTrip) %in% c("LEid", "TEid", "FOid", "OSid", "SDid"))]
	FOtable <- FishingOperation[,!(names(FishingOperation) %in% c("SDid"))]
	SStable <- SpeciesSelection[,!(names(SpeciesSelection) %in% c("LEid","TEid", "FTid", "OSid"))]
	FMtable <- FrequencyMeasure
	VDtable <- VesselDetails
	VStable <- VesselSelection
	BVtable <- BiologicalVariable[,!(names(BiologicalVariable) %in% c("SAid"))]
	SDtable <- SamplingDetails
	DEtable <- Design


	#### for length

	FMSAtable <- merge(FMtable, SAtable_for_length, by=c("SAid"),all.x=TRUE)
	FMSASStable <- merge(FMSAtable, SStable, by=c("SSid"),all.x=TRUE)
	FMSASSFOtable <- merge(FMSASStable, FOtable, by=c("FOid"),all.x=TRUE)
	FMSASSFOFTtable <- merge(FMSASSFOtable, FTtable, by=c("FTid"),all.x=TRUE)
	FMSASSFOFTVDtable <- merge(FMSASSFOFTtable, VDtable, by=c("VDid"),all.x=TRUE)
	FMSASSFOFTVDVStable <- merge(FMSASSFOFTVDtable, VStable, by=c("VSid","VDid"),all.x=TRUE)
	FMSASSFOFTVDVSSDtable <- merge(FMSASSFOFTVDVStable, SDtable, by=c("SDid"),all.x=TRUE)
	FMSASSFOFTVDVSSDDEtable <- merge(FMSASSFOFTVDVSSDtable, DEtable, by=c("DEid"),all.x=TRUE)


	#### for CA

	BVFMSASSFOFTVDVSSDDEtable <- merge(BVtable, FMSASSFOFTVDVSSDDEtable, by=c("FMid"),all.x=TRUE)

	BVFMSASSFOFTVDVSSDDEtable_age <- subset(BVFMSASSFOFTVDVSSDDEtable, substr(BVtypeMeasured,1,3)=="Age")
	
	  if (nrow(BVFMSASSFOFTVDVSSDDEtable_age)==0) 
	  {
	    
	    BVFMSASSFOFTVDVSSDDEtable_age <- BVFMSASSFOFTVDVSSDDEtable%>%distinct(SAid, FMid, VDflagCountry, DEyear, DEsamplingScheme, FTarrivalLocation, FTunitName, FOunitName, FOendDate, FOarea, FOrectangle, FOjurisdictionArea, 
	                                                                          SAspeciesCode, SAlandingCategory, SAcatchCategory, SAcommSizeCat, SAcommSizeCatScale, SAsex, 
	                                                                          FMclassMeasured, FMaccuracy, BVunitName, BVnationalUniqueFishId)
	    BVFMSASSFOFTVDVSSDDEtable_age$BVtypeAssessment <- "Age"
	    BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured <- ''
	    BVFMSASSFOFTVDVSSDDEtable_age$BVanalysisType <- ''
	  }
	

	BVFMSASSFOFTVDVSSDDEtable_weight <- subset(BVFMSASSFOFTVDVSSDDEtable, substr(BVtypeMeasured,1,3)=="Wei")[,c("SAid","FMid",
	"BVnationalUniqueFishId","BVunitName","FMclassMeasured","BVtypeMeasured", "BVvalueMeasured", "BVvalueUnitOrScale", "BVaccuracy","BVanalysisType")]
	
	names(BVFMSASSFOFTVDVSSDDEtable_weight)[(ncol(BVFMSASSFOFTVDVSSDDEtable_weight)-4):ncol(BVFMSASSFOFTVDVSSDDEtable_weight)] <- 
	paste0(names(BVFMSASSFOFTVDVSSDDEtable_weight)[(ncol(BVFMSASSFOFTVDVSSDDEtable_weight)-4):ncol(BVFMSASSFOFTVDVSSDDEtable_weight)],
	"_weight")

	BVFMSASSFOFTVDVSSDDEtable_maturity <- subset(BVFMSASSFOFTVDVSSDDEtable, substr(BVtypeMeasured,1,3)=="Mat")[,c("SAid","FMid",
	"BVnationalUniqueFishId","BVunitName","FMclassMeasured","BVtypeMeasured", "BVvalueMeasured", "BVvalueUnitOrScale", "BVaccuracy","BVanalysisType")]

	names(BVFMSASSFOFTVDVSSDDEtable_maturity)[(ncol(BVFMSASSFOFTVDVSSDDEtable_maturity)-4):ncol(BVFMSASSFOFTVDVSSDDEtable_maturity)] <- 
	paste0(names(BVFMSASSFOFTVDVSSDDEtable_maturity)[(ncol(BVFMSASSFOFTVDVSSDDEtable_maturity)-4):ncol(BVFMSASSFOFTVDVSSDDEtable_maturity)],
	"_maturity")

	BVFMSASSFOFTVDVSSDDEtable_sex <- subset(BVFMSASSFOFTVDVSSDDEtable, substr(BVtypeMeasured,1,3)=="Sex")[,c("SAid","FMid",
	"BVnationalUniqueFishId","BVunitName","FMclassMeasured","BVtypeMeasured", "BVvalueMeasured", "BVvalueUnitOrScale", "BVaccuracy","BVanalysisType")]

	names(BVFMSASSFOFTVDVSSDDEtable_sex)[(ncol(BVFMSASSFOFTVDVSSDDEtable_sex)-4):ncol(BVFMSASSFOFTVDVSSDDEtable_sex)] <- 
	paste0(names(BVFMSASSFOFTVDVSSDDEtable_sex)[(ncol(BVFMSASSFOFTVDVSSDDEtable_sex)-4):ncol(BVFMSASSFOFTVDVSSDDEtable_sex)],
	"_sex")

		if (nrow(BVFMSASSFOFTVDVSSDDEtable_weight)>0) BVFMSASSFOFTVDVSSDDEtable_age <- merge(BVFMSASSFOFTVDVSSDDEtable_age,
		BVFMSASSFOFTVDVSSDDEtable_weight, by=c("SAid","FMid",
		"BVnationalUniqueFishId","BVunitName","FMclassMeasured"), all=TRUE)

		if (nrow(BVFMSASSFOFTVDVSSDDEtable_maturity)>0) BVFMSASSFOFTVDVSSDDEtable_age <- merge(BVFMSASSFOFTVDVSSDDEtable_age,
		BVFMSASSFOFTVDVSSDDEtable_maturity, by=c("SAid","FMid",
		"BVnationalUniqueFishId","BVunitName","FMclassMeasured"), all=TRUE)

		if (nrow(BVFMSASSFOFTVDVSSDDEtable_sex)>0) BVFMSASSFOFTVDVSSDDEtable_age <- merge(BVFMSASSFOFTVDVSSDDEtable_age,
		BVFMSASSFOFTVDVSSDDEtable_sex, by=c("SAid","FMid",
		"BVnationalUniqueFishId","BVunitName","FMclassMeasured"), all=TRUE)
	
	
	########################## TR ###################
	
	FMSASSFOFTVDVSSDDEtable_distinct <- FMSASSFOFTVDVSSDDEtable%>%distinct(DEyear, DEsamplingScheme, SDcountry, VDflagCountry, VSencryptedVesselCode, VDpower, VDtonnage, VDlength, FTunitName, FTarrivalLocation, FTsamplingType, FTsampler, 
	                                                                       FTdepartureDate, FTarrivalDate, FTnumberOfHaulsOrSets)
	
	TR <- data.frame(matrix(nrow = nrow(FMSASSFOFTVDVSSDDEtable_distinct),
	                        ncol=length(TR_rdb.names)), stringsAsFactors = FALSE)
	colnames(TR) <- TR_rdb.names
	
	TR$Record_type <- "TR"
	TR$Sampling_type <- FMSASSFOFTVDVSSDDEtable_distinct$FTsamplingType
	TR$Landing_country <- substr(FMSASSFOFTVDVSSDDEtable_distinct$FTarrivalLocation,1,2)  ## Is it a correct way to extract a Landing Country?
	TR$Vessel_flag_country <- FMSASSFOFTVDVSSDDEtable_distinct$VDflagCountry
	TR$Year <- FMSASSFOFTVDVSSDDEtable_distinct$DEyear
	TR$Project <- FMSASSFOFTVDVSSDDEtable_distinct$DEsamplingScheme
	TR$Trip_number <- FMSASSFOFTVDVSSDDEtable_distinct$FTunitName
	TR$Harbour <- FMSASSFOFTVDVSSDDEtable_distinct$FTarrivalLocation
	TR$Sampling_country <- FMSASSFOFTVDVSSDDEtable_distinct$SDcountry
	TR$Sampling_method <- FMSASSFOFTVDVSSDDEtable_distinct$FTsampler
	TR$Days_at_sea <- round(as.numeric(difftime(FMSASSFOFTVDVSSDDEtable_distinct$FTarrivalDate , FMSASSFOFTVDVSSDDEtable_distinct$FTdepartureDate , units = c("days"))) + 1)
	TR$Number_of_hauls <- FMSASSFOFTVDVSSDDEtable_distinct$FTnumberOfHaulsOrSets
	TR$Vessel_identifier <- FMSASSFOFTVDVSSDDEtable_distinct$VSencryptedVesselCode
	TR$Vessel_type <- 0
	TR$Vessel_length <- FMSASSFOFTVDVSSDDEtable_distinct$VDlength
	TR$Vessel_size <- FMSASSFOFTVDVSSDDEtable_distinct$VDtonnage
	TR$Vessel_power <- FMSASSFOFTVDVSSDDEtable_distinct$VDpower

	TR[is.na(TR)] <- ''

	########################## HL ###################

	HL <- data.frame(matrix(nrow = nrow(FMSASSFOFTVDVSSDDEtable),
	                        ncol=length(HL_rdb.names)), stringsAsFactors = FALSE)
	colnames(HL) <- HL_rdb.names

	HL$Record_type <- "HL"
 	HL$Sampling_type <- FMSASSFOFTVDVSSDDEtable$FTsamplingType
 	HL$Landing_country <- substr(FMSASSFOFTVDVSSDDEtable$FTarrivalLocation,1,2)  ## Is it a correct way to extract a Landing Country?
	HL$Vessel_flag_country <- FMSASSFOFTVDVSSDDEtable$VDflagCountry
	HL$Year <- FMSASSFOFTVDVSSDDEtable$DEyear
	HL$Project <- FMSASSFOFTVDVSSDDEtable$DEsamplingScheme
	HL$Trip_number <- FMSASSFOFTVDVSSDDEtable$FTunitName
	HL$Station_number <- FMSASSFOFTVDVSSDDEtable$FOunitName
	HL$Species <- FMSASSFOFTVDVSSDDEtable$SAspeciesCode
	HL$Catch_category <- FMSASSFOFTVDVSSDDEtable$SAcatchCategory
	HL$Landing_category <- FMSASSFOFTVDVSSDDEtable$SAlandingCategory
	HL$Comm_size_cat_scale <- FMSASSFOFTVDVSSDDEtable$SAcommSizeCatScale
	HL$Comm_size_cat <- FMSASSFOFTVDVSSDDEtable$SAcommSizeCat
	HL$Subsampling_category <- ''								## I didn't find this field in the RDBES
	HL$Sex <- FMSASSFOFTVDVSSDDEtable$SAsex
	HL$Individual_sex <- ''
	HL$Length_class <- FMSASSFOFTVDVSSDDEtable$FMclassMeasured
	HL$Number_at_length <- FMSASSFOFTVDVSSDDEtable$FMnumberAtUnit
	#HL$Hierarchy <- FMSASSFOFTVDVSSDDEtable$DEhierarchy				## Optional

	HL[is.na(HL)] <- ''
	HL <- aggregate(Number_at_length ~ ., data=HL, function(x) sum(x,na.rm=TRUE))


	########################## HH ###################
	
	HH <- data.frame(matrix(nrow = nrow(FMSASSFOFTVDVSSDDEtable), ncol=length(HH_rdb.names)), stringsAsFactors = FALSE)
	colnames(HH) <- HH_rdb.names

	HH$Record_type <- "HH"
 	HH$Sampling_type <- FMSASSFOFTVDVSSDDEtable$FTsamplingType
 	HH$Landing_country <- substr(FMSASSFOFTVDVSSDDEtable$FTarrivalLocation,1,2)  ## Is it a correct way to extract a Landing Country?
	HH$Vessel_flag_country <- FMSASSFOFTVDVSSDDEtable$VDflagCountry
	HH$Year <- FMSASSFOFTVDVSSDDEtable$DEyear
	HH$Project <- FMSASSFOFTVDVSSDDEtable$DEsamplingScheme
	HH$Trip_number <- FMSASSFOFTVDVSSDDEtable$FTunitName
	HH$Station_number <- FMSASSFOFTVDVSSDDEtable$FOunitName
	HH$Fishing_validity <- FMSASSFOFTVDVSSDDEtable$FOvalidity
	HH$Aggregation_level <- FMSASSFOFTVDVSSDDEtable$FOaggregationLevel
	HH$Catch_registration <- FMSASSFOFTVDVSSDDEtable$FOcatchReg 
	HH$Species_registration <- ''										## Didn't find what is that in RDBES       
	HH$Date <- FMSASSFOFTVDVSSDDEtable$FOstartDate  
	HH$Time <- FMSASSFOFTVDVSSDDEtable$FOstartTime
	HH$Fishing_duration <- FMSASSFOFTVDVSSDDEtable$FOduration
	HH$Pos_Start_Lat_dec <- FMSASSFOFTVDVSSDDEtable$FOstartLat
	HH$Pos_Start_Lon_dec <- FMSASSFOFTVDVSSDDEtable$FOstartLon
	HH$Pos_Stop_Lat_dec <- FMSASSFOFTVDVSSDDEtable$FOstopLat
	HH$Pos_Stop_Lon_dec <- FMSASSFOFTVDVSSDDEtable$FOstopLon
	HH$Area <- FMSASSFOFTVDVSSDDEtable$FOarea
	HH$Statistical_rectangle <- FMSASSFOFTVDVSSDDEtable$FOrectangle
	HH$Sub_polygon <- FMSASSFOFTVDVSSDDEtable$FOjurisdictionArea
	HH$Main_fishing_depth <- FMSASSFOFTVDVSSDDEtable$FOfishingDepth
	HH$Main_water_depth <- FMSASSFOFTVDVSSDDEtable$FOwaterDepth
	HH$FAC_National <- FMSASSFOFTVDVSSDDEtable$FOnationalFishingActivity
	HH$FAC_EC_lvl5 <- FMSASSFOFTVDVSSDDEtable$FOmetier5
	HH$FAC_EC_lvl6 <- FMSASSFOFTVDVSSDDEtable$FOmetier6
	HH$Gear_type <- FMSASSFOFTVDVSSDDEtable$FOgear
	HH$Mesh_size <- FMSASSFOFTVDVSSDDEtable$FOmeshSize
	HH$Selection_device <- FMSASSFOFTVDVSSDDEtable$FOselectionDevice
	HH$Mesh_size_selection_device <- FMSASSFOFTVDVSSDDEtable$FOselectionDeviceMeshSize
	#HH$Hierarchy <- FMSASSFOFTVDVSSDDEtable$DEhierarchy 				## Optional

	HH[is.na(HH)] <- ''
	HH <- distinct(HH)

	########################## SL ###################
	
	SL <- data.frame(matrix(nrow = nrow(FMSASSFOFTVDVSSDDEtable), ncol=length(SL_rdb.names)), stringsAsFactors = FALSE)
	colnames(SL) <- SL_rdb.names

	SL$Record_type <- "SL"
 	SL$Sampling_type <- FMSASSFOFTVDVSSDDEtable$FTsamplingType
 	SL$Landing_country <- substr(FMSASSFOFTVDVSSDDEtable$FTarrivalLocation,1,2)  ## Is it a correct way to extract a Landing Country?
	SL$Vessel_flag_country <- FMSASSFOFTVDVSSDDEtable$VDflagCountry
	SL$Year <- FMSASSFOFTVDVSSDDEtable$DEyear
	SL$Project <- FMSASSFOFTVDVSSDDEtable$DEsamplingScheme
	SL$Trip_number <- FMSASSFOFTVDVSSDDEtable$FTunitName
	SL$Station_number <- FMSASSFOFTVDVSSDDEtable$FOunitName
	SL$Species <- FMSASSFOFTVDVSSDDEtable$SAspeciesCode
	SL$Catch_category <- FMSASSFOFTVDVSSDDEtable$SAcatchCategory
	SL$Landing_category <- FMSASSFOFTVDVSSDDEtable$SAlandingCategory
	SL$Comm_size_cat_scale <- FMSASSFOFTVDVSSDDEtable$SAcommSizeCatScale
	SL$Comm_size_cat <- FMSASSFOFTVDVSSDDEtable$SAcommSizeCat
	SL$Subsampling_category <- ''										## I didn't find this field in the RDBES
	SL$Sex <- FMSASSFOFTVDVSSDDEtable$SAsex
	SL$Weight <- FMSASSFOFTVDVSSDDEtable$SAtotalWeightLive 
	SL$Subsample_weight <- FMSASSFOFTVDVSSDDEtable$SAsampleWeightLive
	SL$Length_code <- 'mm'
	#SL$Hierarchy <- FMSASSFOFTVDVSSDDEtable$DEhierarchy 				## Optional
	
	SL[is.na(SL)] <- ''
	SL <- distinct(SL)


	########################## CA ###################
	
	CA <- data.frame(matrix(nrow = nrow(BVFMSASSFOFTVDVSSDDEtable_age), ncol=length(CA_rdb.names)), stringsAsFactors = FALSE)
	colnames(CA) <- CA_rdb.names
	

	CA$Record_type <- "CA"
 	CA$Sampling_type <- BVFMSASSFOFTVDVSSDDEtable_age$FTsamplingType
 	CA$Landing_country <- substr(BVFMSASSFOFTVDVSSDDEtable_age$FTarrivalLocation,1,2)  ## Is it a correct way to extract a Landing Country?
	CA$Vessel_flag_country <- BVFMSASSFOFTVDVSSDDEtable_age$VDflagCountry
	CA$Year <- BVFMSASSFOFTVDVSSDDEtable_age$DEyear
	CA$Project <- BVFMSASSFOFTVDVSSDDEtable_age$DEsamplingScheme
	CA$Trip_number <- BVFMSASSFOFTVDVSSDDEtable_age$FTunitName
	CA$Station_number <- BVFMSASSFOFTVDVSSDDEtable_age$FOunitName
	CA$Quarter <- ifelse(as.numeric(substr(BVFMSASSFOFTVDVSSDDEtable_age$FOendDate, 6, 7)) %in% 1:3, 1,
				ifelse(as.numeric(substr(BVFMSASSFOFTVDVSSDDEtable_age$FOendDate, 6, 7)) %in% 4:6, 2,
				ifelse(as.numeric(substr(BVFMSASSFOFTVDVSSDDEtable_age$FOendDate, 6, 7)) %in% 7:9, 3, 4)))
	CA$Month <- as.numeric(substr(BVFMSASSFOFTVDVSSDDEtable_age$FOendDate, 6, 7))
	CA$Species <- BVFMSASSFOFTVDVSSDDEtable_age$SAspeciesCode
	if (!is.null(BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_sex)) 
		CA$Sex <- ifelse(is.na(BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_sex), 
		BVFMSASSFOFTVDVSSDDEtable_age$SAsex, 
		BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_sex) else CA$Sex <- BVFMSASSFOFTVDVSSDDEtable_age$SAsex
	CA$Catch_category <- BVFMSASSFOFTVDVSSDDEtable_age$SAcatchCategory
	CA$Landing_category <- BVFMSASSFOFTVDVSSDDEtable_age$SAlandingCategory
	CA$Comm_size_cat_scale <- BVFMSASSFOFTVDVSSDDEtable_age$SAcommSizeCatScale
	CA$Comm_size_cat <- BVFMSASSFOFTVDVSSDDEtable_age$SAcommSizeCat
	CA$Stock <- ''												## paste0(species_name, area)?
	CA$Area <- BVFMSASSFOFTVDVSSDDEtable_age$FOarea
	CA$Statistical_rectangle <- BVFMSASSFOFTVDVSSDDEtable_age$FOrectangle
	CA$Sub_polygon <- BVFMSASSFOFTVDVSSDDEtable_age$FOjurisdictionArea
	CA$Length_class <- BVFMSASSFOFTVDVSSDDEtable_age$FMclassMeasured
	CA$Age <- BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured
	CA$Single_fish_number <- BVFMSASSFOFTVDVSSDDEtable_age$BVnationalUniqueFishId
	CA$Length_code <- BVFMSASSFOFTVDVSSDDEtable_age$FMaccuracy
	CA$Aging_method <- BVFMSASSFOFTVDVSSDDEtable_age$BVanalysisType
	CA$Age_plus_group <- ''												## ??
	CA$Otolith_weight <- ''												## ??
	CA$Otolith_side <- ''												## ??
	if (!is.null(BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_weight))   					## BVvalueMeasured
	CA$Weight <- ifelse(is.na(BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_weight), 
		NA, BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_weight) else CA$Weight <- NA

	if (!is.null(BVFMSASSFOFTVDVSSDDEtable_age$BVmethod_maturity))  						## BVmethod
		CA$Maturity_staging_method <- ifelse(is.na(BVFMSASSFOFTVDVSSDDEtable_age$BVmethod_maturity), 
		NA, BVFMSASSFOFTVDVSSDDEtable_age$BVmethod_maturity) else CA$Maturity_staging_method <- NA

	if (!is.null(BVFMSASSFOFTVDVSSDDEtable_age$BVvalueUnitOrScale_maturity)) 					## BVvalueUnitOrScale
		CA$Maturity_scale <- ifelse(is.na(BVFMSASSFOFTVDVSSDDEtable_age$BVvalueUnitOrScale_maturity), 
		NA, BVFMSASSFOFTVDVSSDDEtable_age$BVvalueUnitOrScale_maturity) else CA$Maturity_scale <- NA

	if (!is.null(BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_maturity)) 					## BVvalueMeasured
		CA$Maturity_stage <- ifelse(is.na(BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_maturity), 
		NA, BVFMSASSFOFTVDVSSDDEtable_age$BVvalueMeasured_maturity) else CA$Maturity_stage <- NA
	
#CA$Hierarchy <- BVFMSASSFOFTVDVSSDDEtable_age$DEhierarchy 				## Optional

	CA[is.na(CA)] <- ''
	

	} else

{
TR <- NULL
HL <- NULL
HH <- NULL
SL <- NULL
CA <- NULL
}

return(list(TR = TR, HL = HL, HH = HH, SL = SL, CA = CA))
}

