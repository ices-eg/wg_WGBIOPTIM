#### This script computes between original and subsampled data sets
#### Inputs and parameters: data - original data set; subsample - subsampled data set (may be a reference subsample or any "real-world" subsample); important - defined important length classes where distance is calculated; 
#### reference - if TRUE, than subsample = reference subsample and ADV is computed, if FALSE, than subsample = "real-world" subsample and distance is computed and can be than compared to ADV.
#### Ouputs: distance value + plot with empirical cumulative functions of original and subsampled data sets

distanceComputation <- function(dataset.original, dataset.reference, dataset.reduced = NULL, const = c(0.5, 0.25, 0.25), epsilon = epsilon, theta = theta, delta = delta, important = NULL)

{
  years <- sort(unique(dataset.original$Year))

  if (missing(important)) important <- seq(0, max(dataset.original$Length_class), by = 10)
  
  M <- max(dataset.original$Length_class)
  
  dataset.original$Data <- "original sample"
  dataset.reference$Data <- "reference subsample"
  dataset <- rbind(dataset.original[, c("Year", "Quarter", "FAO", "Length_class", "Data")], dataset.reference[, c("Year", "Quarter", "FAO", "Length_class", "Data")])
  
  CDF_dataset.original <- lapply(split(subset(dataset.original, Length_class %in% important), list(dataset.original$Year)), function(x) ecdf(x$Length_class)(important))
  CDF_dataset.reference <- lapply(split(subset(dataset.reference, Length_class %in% important), list(dataset.reference$Year)), function(x) ecdf(x$Length_class)(important))
  
  
  T_dataset.original <- data.frame(do.call(cbind, CDF_dataset.original))%>%add_column(important)%>%set_names(c(paste0("Year_", names(CDF_dataset.original)), "Length_class"))%>%
    add_column(Data = "original")
  T_dataset.reference <- data.frame(do.call(cbind, CDF_dataset.reference))%>%add_column(important)%>%set_names(c(paste0("Year_", names(CDF_dataset.reference)), "Length_class"))%>%
    add_column(Data = "reference")
    
  
  if (!missing(dataset.reduced))
  {
    
    dataset.reduced$Data <- "subsample"
    dataset <- rbind(dataset, dataset.reduced[, c("Year", "Quarter", "FAO", "Length_class", "Data")])
    
    
    CDF_dataset.reduced <- lapply(split(subset(dataset.reduced, Length_class %in% important), list(dataset.reduced$Year)), function(x) ecdf(x$Length_class)(important))
    T_dataset.reduced <- data.frame(do.call(cbind, CDF_dataset.reduced))%>%add_column(important)%>%set_names(c(paste0("Year_", names(CDF_dataset.reduced)), "Length_class"))%>%
      add_column(Data = "subsample")
    
    ADV <- data.frame(matrix(nrow = 0, ncol = 2))
    for (y in years)
    {
      T_year.original <- cbind(T_dataset.original%>%select(contains(paste0("Year_",y))), T_dataset.original%>%select(contains("Length_class")))
      T_year.reference <- cbind(T_dataset.reference%>%select(contains(paste0("Year_",y))), T_dataset.reference%>%select(contains("Length_class")))
      
      ADV <- rbind(ADV, c(y, round(dist(rbind(T_year.original[,1], T_year.reference[,1]), method ="manhattan"),4)))
    }
    names(ADV) <- c("Year", "ADV")
    
    
    Distance <- data.frame(matrix(nrow = 0, ncol = 2))
    for (y in years)
    {
      T_year.original <- cbind(T_dataset.original%>%select(contains(paste0("Year_",y))), T_dataset.original%>%select(contains("Length_class")))
      T_year.reduced <- cbind(T_dataset.reduced%>%select(contains(paste0("Year_",y))), T_dataset.reduced%>%select(contains("Length_class")))
      
      Distance <- rbind(Distance, c(y, round(dist(rbind(T_year.original[,1], T_year.reduced[,1]), method ="manhattan"),4)))
    }
    names(Distance) <- c("Year", "Distance_initial")
    
    
    dataset <- merge(dataset, ADV, by = "Year", all.x=TRUE)
    
    
    #### Penalties
    
    distributional.shape_subsample <- findModesAntimodes(dataset.reduced, delta = delta, important = important)
    distributional.shape_original <- findModesAntimodes(dataset.original, delta = delta, important = important)
    
    ### PC 1
    
    n_modes_original <- distributional.shape_original$modes_robust%>%group_by(Year)%>%summarize(N_modes_original = n())
    n_antimodes_original <- distributional.shape_original$antimodes_robust%>%group_by(Year)%>%summarize(N_antimodes_original = n())
    
    n_modes_subsample <- distributional.shape_subsample$modes_robust%>%group_by(Year)%>%summarize(N_modes_subsample = n())
    n_antimodes_subsample <- distributional.shape_subsample$antimodes_robust%>%group_by(Year)%>%summarize(N_antimodes_subsample = n())
    
    N_modes_antimodes <- n_modes_original%>%merge(n_antimodes_original, by="Year", all = TRUE)%>%
      merge(n_modes_subsample, by="Year", all = TRUE)%>%merge(n_antimodes_subsample, by="Year", all = TRUE)%>%
      add_column(PC_1 = const[1])%>%
      filter(N_modes_subsample!=N_modes_original | N_antimodes_subsample!=N_antimodes_original)
    
    if (nrow(N_modes_antimodes)>0)  
    {
      N_modes_antimodes <- N_modes_antimodes%>%select(Year, PC_1)
      Distance <- merge(Distance, N_modes_antimodes, by="Year", all.x=TRUE)
      Distance$PC_1 <- ifelse(is.na(Distance$PC_1), 0, Distance$PC_1 * Distance$Distance_initial)
   } else Distance$PC_1 <- 0
    
    
     
     #### PC 2
     
     modes_original <- distributional.shape_original$modes_robust%>%rename(Modes_original = Length_class, Count_original = Count)%>%
       group_by(Year)%>%mutate(mode_number = row_number())
     
     modes_subsample <- distributional.shape_subsample$modes_robust%>%rename(Modes_subsample = Length_class, Count_subsample = Count)%>%
       group_by(Year)%>%mutate(mode_number = row_number())
     
     antimodes_original <- distributional.shape_original$antimodes_robust%>%rename(Antimodes_original = Length_class, Count_original = Count)%>%
       group_by(Year)%>%mutate(antimode_number = row_number())
     
     antimodes_subsample <- distributional.shape_subsample$antimodes_robust%>%rename(Antimodes_subsample = Length_class, Count_subsample = Count)%>%
       group_by(Year)%>%mutate(antimode_number = row_number())
     
     modes_original_subsample <- modes_original%>%full_join(modes_subsample, by=c("Year", "mode_number"))%>% ### code has to be revised here: to determine which mode exactly, the fist or second one?
       mutate(diff = abs(Modes_original - Modes_subsample))%>%
       add_column(C_2 = const[2])%>%
       subset(!is.na(diff))%>%
       group_by(Year)%>%summarise(PC_2_mode = sum(max(0, (diff - epsilon))*C_2))
     
     
     antimodes_original_subsample <- antimodes_original%>%full_join(antimodes_subsample, by=c("Year", "antimode_number"))%>% ### code has to be revised here: to determine which antimode exactly, the fist or second one?
       mutate(diff = abs(Antimodes_original - Antimodes_subsample))%>%
       add_column(C_2 = const[2])%>%
       subset(!is.na(diff))%>%
       group_by(Year)%>%
       summarise(PC_2_antimode = sum(max(0, (diff - epsilon))*C_2))
     
     Location_modes_antimodes <- merge(modes_original_subsample, antimodes_original_subsample, by="Year", all = TRUE)%>%
       subset(!is.na(PC_2_mode) & !is.na(PC_2_antimode))%>%
       mutate(PC_2 = PC_2_mode + PC_2_antimode)%>%
       select(Year, PC_2)
     
     Distance <- merge(Distance, Location_modes_antimodes, by="Year", all.x=TRUE)
     Distance$PC_2 <- ifelse(is.na(Distance$PC_2), 0, Distance$PC_2 * Distance$Distance_initial)
     
     ### PC 3
     
     ranges_original <- distributional.shape_original$range_robust%>%select(Year, Diff)%>%rename(Ranges_original = Diff)%>%group_by(Year)%>%mutate(range_number = row_number())
     ranges_subsample <- distributional.shape_subsample$range_robust%>%select(Year, Diff)%>%rename(Ranges_subsample = Diff)%>%group_by(Year)%>%mutate(range_number = row_number())
     
     ranges_original_subsample <- ranges_original%>%full_join(ranges_subsample, by=c("Year", "range_number"))%>%
       mutate(ratio = Ranges_subsample/Ranges_original)%>%
       add_column(C_3 = const[3])
     
     Raio_modes_antimodes <- ranges_original_subsample%>%
       group_by(Year)%>%summarise(PC_3 = sum(max(0, (theta - ratio))*C_3))
     
     
     Distance <- merge(Distance, Raio_modes_antimodes, by="Year", all.x=TRUE)
     Distance$PC_3 <- ifelse(is.na(Distance$PC_3), 0, Distance$PC_3 * Distance$Distance_initial)
     
    

     Distance$Distance <- round((Distance$Distance_initial + Distance$PC_1 + Distance$PC_2 + Distance$PC_3), 4)

    
  
    
    dataset <- merge(dataset, Distance, by = "Year", all.x=TRUE)
    
    #### Plot
    
    ggplot(dataset, aes(Length_class, color = Data, linetype = Data)) + 
      stat_ecdf(geom = "step",  linewidth = 1) + 
      facet_wrap(~ Year) +
      xlim(0, max(important)) +
      scale_colour_manual(values = c("original sample" = "deepskyblue1", "reference subsample" = "yellowgreen", "subsample" = "tomato1")) + 
      scale_linetype_manual(values = c("original sample" = 1, "reference subsample" = 1, "subsample" = 2)) +
      #xlim(0,M)+
      #ylim(0,1)+
      labs(x="LENGTH (mm, binwidth = 10 mm)", y = "CDF") +
      theme(legend.position = "bottom",
            legend.title = element_blank(),
            legend.text = element_text(face="bold", size=13),
            plot.title = element_text(face="bold", size=15, hjust = 0.5, color = "deepskyblue3"), 
            plot.subtitle = element_text(face="bold", size=12, hjust = 0.5),
            axis.title = element_text(face="bold", size = 14), 
            axis.text = element_text(face="bold", size = 12),
            text = element_text(size = 12),
            strip.text = element_text(size=15, face="bold.italic")) +
      geom_text(x= round(M/5), y = 0.9, label = paste0("ADV = ", dataset$ADV), color = "darkblue", fontface = "bold") +
      geom_text(x= round(M/5), y = 0.8, label = paste0("D = ", dataset$Distance), color = "darkred", fontface = "bold")
    
    
  } else 
    
  {
    
    ADV <- data.frame(matrix(nrow = 0, ncol = 2))
    for (y in years)
    {
      T_year.original <- cbind(T_dataset.original%>%select(contains(paste0("Year_",y))), T_dataset.original%>%select(contains("Length_class")))
      T_year.reference <- cbind(T_dataset.reference%>%select(contains(paste0("Year_",y))), T_dataset.reference%>%select(contains("Length_class")))
      
      ADV <- rbind(ADV, c(y, round(dist(rbind(T_year.original[,1], T_year.reference[,1]), method ="manhattan"),4)))
    }
    names(ADV) <- c("Year", "ADV")
    
    dataset <- merge(dataset, ADV, by = "Year", all.x=TRUE)
    
    #### Plot
    
    ggplot(dataset, aes(Length_class, color = Data)) + 
    stat_ecdf(geom = "step",  linewidth = 1) + 
    facet_wrap(~ Year) +
    xlim(0, max(important)) +
    scale_colour_manual(values = c("original sample" = "deepskyblue1", "reference subsample" = "yellowgreen")) + 
    #xlim(0,M)+
    #ylim(0,1)+
    labs(x="LENGTH (mm, binwidth = 10 mm)", y = "CDF") +
    theme(legend.position = "bottom",
          legend.title = element_blank(),
          legend.text = element_text(face="bold", size=13),
          plot.title = element_text(face="bold", size=15, hjust = 0.5, color = "deepskyblue3"), 
          plot.subtitle = element_text(face="bold", size=12, hjust = 0.5),
          axis.title = element_text(face="bold", size = 14), 
          axis.text = element_text(face="bold", size = 12),
          text = element_text(size = 12),
          strip.text = element_text(size=15, face="bold.italic")) +
    geom_text(x= round(M/5), y = 0.9, label = paste0("ADV = ", dataset$ADV), color = "darkblue", fontface = "bold")
    
  }
  

  }
  
  

